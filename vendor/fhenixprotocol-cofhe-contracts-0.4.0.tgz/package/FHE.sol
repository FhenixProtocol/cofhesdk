// SPDX-License-Identifier: BSD-3-Clause-Clear
// solhint-disable one-contract-per-file

pragma solidity >=0.8.25 <0.9.0;

import {Strings} from "@openzeppelin/contracts/utils/Strings.sol";
import {FunctionId, ITaskManager, ICoFHEAddressBook, Utils, EncryptedInput, UnsignedEncryptedInput} from "./ICofhe.sol";

type ebool is bytes32;
type euint8 is bytes32;
type euint16 is bytes32;
type euint32 is bytes32;
type euint64 is bytes32;
type euint128 is bytes32;
type eaddress is bytes32;

type externalEbool is bytes32;
type externalEuint8 is bytes32;
type externalEuint16 is bytes32;
type externalEuint32 is bytes32;
type externalEuint64 is bytes32;
type externalEuint128 is bytes32;
type externalEaddress is bytes32;

type sharedEbool is bytes32;
type sharedEuint8 is bytes32;
type sharedEuint16 is bytes32;
type sharedEuint32 is bytes32;
type sharedEuint64 is bytes32;
type sharedEuint128 is bytes32;
type sharedEaddress is bytes32;

// The CoFHEAddressBook proxy - one fixed address on every chain - resolves TASK_MANAGER_ID to the
// TaskManager this release of FHE.sol talks to.
//solhint-disable const-name-snakecase
address constant COFHE_ADDRESS_BOOK = 0xC0F4e00E531a2B086492Ae3DCC1515038307196b;
uint256 constant TASK_MANAGER_ID = 1;

library Common {
    function tm() internal view returns (ITaskManager) {
        return ITaskManager(ICoFHEAddressBook(COFHE_ADDRESS_BOOK).getTm(TASK_MANAGER_ID));
    }

    error InvalidHexCharacter(bytes1 char);
    error SecurityZoneOutOfBounds(int32 value);

    // Default value for temp hash calculation in unary operations
    string private constant DEFAULT_VALUE = "0";

    function convertInt32ToUint256(int32 value) internal pure returns (uint256) {
        if (value < 0) {
            revert SecurityZoneOutOfBounds(value);
        }
        return uint256(uint32(value));
    }

    function isInitialized(bytes32 hash) internal pure returns (bool) {
        return hash != 0;
    }

    // Return true if the encrypted integer is initialized and false otherwise.
    function isInitialized(ebool v) internal pure returns (bool) {
        return isInitialized(ebool.unwrap(v));
    }

    // Return true if the encrypted integer is initialized and false otherwise.
    function isInitialized(euint8 v) internal pure returns (bool) {
        return isInitialized(euint8.unwrap(v));
    }

    // Return true if the encrypted integer is initialized and false otherwise.
    function isInitialized(euint16 v) internal pure returns (bool) {
        return isInitialized(euint16.unwrap(v));
    }

    // Return true if the encrypted integer is initialized and false otherwise.
    function isInitialized(euint32 v) internal pure returns (bool) {
        return isInitialized(euint32.unwrap(v));
    }

    // Return true if the encrypted integer is initialized and false otherwise.
    function isInitialized(euint64 v) internal pure returns (bool) {
        return isInitialized(euint64.unwrap(v));
    }

    // Return true if the encrypted integer is initialized and false otherwise.
    function isInitialized(euint128 v) internal pure returns (bool) {
        return isInitialized(euint128.unwrap(v));
    }


    function isInitialized(eaddress v) internal pure returns (bool) {
        return isInitialized(eaddress.unwrap(v));
    }

    function createUint256Inputs(bytes32 input1) internal pure returns (uint256[] memory) {
        uint256[] memory inputs = new uint256[](1);
        inputs[0] = uint256(input1);
        return inputs;
    }

    function createUint256ExtraInputs(uint256 input1) internal pure returns (uint256[] memory) {
        uint256[] memory inputs = new uint256[](1);
        inputs[0] = uint256(input1);
        return inputs;
    }

    function createUint256Inputs(bytes32 input1, bytes32 input2) internal pure returns (uint256[] memory) {
        uint256[] memory inputs = new uint256[](2);
        inputs[0] = uint256(input1);
        inputs[1] = uint256(input2);
        return inputs;
    }

    function createUint256Inputs(bytes32 input1, bytes32 input2, bytes32 input3) internal pure returns (uint256[] memory) {
        uint256[] memory inputs = new uint256[](3);
        inputs[0] = uint256(input1);
        inputs[1] = uint256(input2);
        inputs[2] = uint256(input3);
        return inputs;
    }

    function createUint256ExtraInputs(uint256 input1, uint256 input2, uint256 input3) internal pure returns (uint256[] memory) {
        uint256[] memory inputs = new uint256[](3);
        inputs[0] = input1;
        inputs[1] = input2;
        inputs[2] = input3;
        return inputs;
    }
}

library Impl {
    function trivialEncrypt(uint256 value, uint8 toType, int32 securityZone) internal returns (bytes32) {
        return bytes32(Common.tm().createTask(toType, FunctionId.trivialEncrypt, new uint256[](0), Common.createUint256ExtraInputs(value, toType, Common.convertInt32ToUint256(securityZone))));
    }

    function cast(bytes32 key, uint8 toType) internal returns (bytes32) {
        return bytes32(Common.tm().createTask(toType, FunctionId.cast, Common.createUint256Inputs(key), Common.createUint256ExtraInputs(toType)));
    }

    function select(uint8 returnType, ebool control, bytes32 ifTrue, bytes32 ifFalse) internal returns (bytes32 result) {
        return bytes32(Common.tm().createTask(returnType,
            FunctionId.select,
            Common.createUint256Inputs(ebool.unwrap(control), ifTrue, ifFalse),
            new uint256[](0)));
    }

    function mathOp(uint8 returnType, bytes32 lhs, bytes32 rhs, FunctionId functionId) internal returns (bytes32) {
        return bytes32(Common.tm().createTask(returnType, functionId, Common.createUint256Inputs(lhs, rhs), new uint256[](0)));
    }

    function getDecryptResult(bytes32 input) internal view returns (uint256) {
        return Common.tm().getDecryptResult(uint256(input));
    }

    function getDecryptResultSafe(bytes32 input) internal view returns (uint256 result, bool decrypted) {
        return Common.tm().getDecryptResultSafe(uint256(input));
    }

    function publishDecryptResult(bytes32 ctHash, uint256 result, bytes memory signature) internal {
        Common.tm().publishDecryptResult(uint256(ctHash), result, signature);
    }

    function publishDecryptResultBatch(uint256[] memory ctHashes, uint256[] memory results, bytes[] memory signatures) internal {
        Common.tm().publishDecryptResultBatch(ctHashes, results, signatures);
    }

    function publishDecryptResultBatch(bytes32[] memory ctHashes, uint256[] memory results, bytes[] memory signatures) internal {
        uint256[] memory ctHashesUint = new uint256[](ctHashes.length);
        for (uint256 i = 0; i < ctHashes.length; i++) {
            ctHashesUint[i] = uint256(ctHashes[i]);
        }
        publishDecryptResultBatch(ctHashesUint, results, signatures);
    }

    function verifyDecryptResult(bytes32 ctHash, uint256 result, bytes memory signature) internal view returns (bool) {
        return Common.tm().verifyDecryptResult(uint256(ctHash), result, signature);
    }

    function verifyDecryptResultSafe(bytes32 ctHash, uint256 result, bytes memory signature) internal view returns (bool) {
        return Common.tm().verifyDecryptResultSafe(uint256(ctHash), result, signature);
    }

    function verifyDecryptResultBatch(uint256[] memory ctHashes, uint256[] memory results, bytes[] memory signatures) internal view returns (bool) {
        return Common.tm().verifyDecryptResultBatch(ctHashes, results, signatures);
    }

    function verifyDecryptResultBatch(bytes32[] memory ctHashes, uint256[] memory results, bytes[] memory signatures) internal view returns (bool) {
        uint256[] memory ctHashesUint = new uint256[](ctHashes.length);
        for (uint256 i = 0; i < ctHashes.length; i++) {
            ctHashesUint[i] = uint256(ctHashes[i]);
        }
        return verifyDecryptResultBatch(ctHashesUint, results, signatures);
    }

    function verifyDecryptResultBatchSafe(uint256[] memory ctHashes, uint256[] memory results, bytes[] memory signatures) internal view returns (bool[] memory) {
        return Common.tm().verifyDecryptResultBatchSafe(ctHashes, results, signatures);
    }

    function verifyDecryptResultBatchSafe(bytes32[] memory ctHashes, uint256[] memory results, bytes[] memory signatures) internal view returns (bool[] memory) {
        uint256[] memory ctHashesUint = new uint256[](ctHashes.length);
        for (uint256 i = 0; i < ctHashes.length; i++) {
            ctHashesUint[i] = uint256(ctHashes[i]);
        }
        return verifyDecryptResultBatchSafe(ctHashesUint, results, signatures);
    }

    function not(uint8 returnType, bytes32 input) internal returns (bytes32) {
        return bytes32(Common.tm().createTask(returnType, FunctionId.not, Common.createUint256Inputs(input), new uint256[](0)));
    }

    function square(uint8 returnType, bytes32 input) internal returns (bytes32) {
        return bytes32(Common.tm().createTask(returnType, FunctionId.square, Common.createUint256Inputs(input), new uint256[](0)));
    }

    /// @dev A single input is a batch of one: the signature must cover
    ///      keccak256(h_0), the batch digest `batchVerifyInputs` rebuilds for a
    ///      one-element batch.
    function verifyInput(EncryptedInput memory input) internal returns (bytes32) {
        UnsignedEncryptedInput[] memory inputs = new UnsignedEncryptedInput[](1);
        inputs[0] = UnsignedEncryptedInput(input.ctHash, input.securityZone, input.utype);
        return verifyBatchInputs(inputs, input.signature)[0];
    }

    function verifyBatchInputs(UnsignedEncryptedInput[] memory inputs, bytes memory signature) internal returns (bytes32[] memory hashes) {
        uint256[] memory handles = Common.tm().batchVerifyInputs(inputs, msg.sender, signature);
        // uint256[] and bytes32[] have identical memory layout, so reinterpret in place instead of copying.
        assembly ("memory-safe") {
            hashes := handles
        }
    }

    /// @notice Generates a random value of a given type with the given seed, for the provided securityZone
    /// @dev Calls the desired function
    /// @param uintType the type of the random value to generate
    /// @param seed the seed to use to create a random value from
    /// @param securityZone the security zone to use for the random value
    function random(uint8 uintType, uint256 seed, int32 securityZone) internal returns (bytes32) {
        return bytes32(Common.tm().createRandomTask(uintType, seed, securityZone));
    }

    /// @notice Generates a random value of a given type with the given seed
    /// @dev Calls the desired function
    /// @param uintType the type of the random value to generate
    /// @param seed the seed to use to create a random value from
    function random(uint8 uintType, uint256 seed) internal returns (bytes32) {
        return random(uintType, seed, 0);
    }

    /// @notice Generates a random value of a given type
    /// @dev Calls the desired function
    /// @param uintType the type of the random value to generate
    function random(uint8 uintType) internal returns (bytes32) {
        return random(uintType, 0, 0);
    }
}

library FHE {
    /// @notice Perform the addition operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted addition
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type euint8 containing the addition result
    function add(euint8 lhs, euint8 rhs) internal returns (euint8) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return euint8.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.add));
    }

    /// @notice Perform the addition operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted addition
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type euint16 containing the addition result
    function add(euint16 lhs, euint16 rhs) internal returns (euint16) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return euint16.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.add));
    }

    /// @notice Perform the addition operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted addition
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type euint32 containing the addition result
    function add(euint32 lhs, euint32 rhs) internal returns (euint32) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return euint32.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.add));
    }

    /// @notice Perform the addition operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted addition
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type euint64 containing the addition result
    function add(euint64 lhs, euint64 rhs) internal returns (euint64) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return euint64.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.add));
    }

    /// @notice Perform the addition operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted addition
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type euint128 containing the addition result
    function add(euint128 lhs, euint128 rhs) internal returns (euint128) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return euint128.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.add));
    }


    /// @notice Perform the less than or equal to operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type ebool containing the comparison result
    function lte(euint8 lhs, euint8 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.lte));
    }

    /// @notice Perform the less than or equal to operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type ebool containing the comparison result
    function lte(euint16 lhs, euint16 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.lte));
    }

    /// @notice Perform the less than or equal to operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type ebool containing the comparison result
    function lte(euint32 lhs, euint32 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.lte));
    }

    /// @notice Perform the less than or equal to operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type ebool containing the comparison result
    function lte(euint64 lhs, euint64 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.lte));
    }

    /// @notice Perform the less than or equal to operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type ebool containing the comparison result
    function lte(euint128 lhs, euint128 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.lte));
    }


    /// @notice Perform the subtraction operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted subtraction
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type euint8 containing the subtraction result
    function sub(euint8 lhs, euint8 rhs) internal returns (euint8) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return euint8.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.sub));
    }

    /// @notice Perform the subtraction operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted subtraction
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type euint16 containing the subtraction result
    function sub(euint16 lhs, euint16 rhs) internal returns (euint16) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return euint16.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.sub));
    }

    /// @notice Perform the subtraction operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted subtraction
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type euint32 containing the subtraction result
    function sub(euint32 lhs, euint32 rhs) internal returns (euint32) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return euint32.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.sub));
    }

    /// @notice Perform the subtraction operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted subtraction
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type euint64 containing the subtraction result
    function sub(euint64 lhs, euint64 rhs) internal returns (euint64) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return euint64.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.sub));
    }

    /// @notice Perform the subtraction operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted subtraction
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type euint128 containing the subtraction result
    function sub(euint128 lhs, euint128 rhs) internal returns (euint128) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return euint128.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.sub));
    }


    /// @notice Perform the multiplication operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted multiplication
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type euint8 containing the multiplication result
    function mul(euint8 lhs, euint8 rhs) internal returns (euint8) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return euint8.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.mul));
    }

    /// @notice Perform the multiplication operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted multiplication
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type euint16 containing the multiplication result
    function mul(euint16 lhs, euint16 rhs) internal returns (euint16) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return euint16.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.mul));
    }

    /// @notice Perform the multiplication operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted multiplication
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type euint32 containing the multiplication result
    function mul(euint32 lhs, euint32 rhs) internal returns (euint32) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return euint32.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.mul));
    }

    /// @notice Perform the multiplication operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted multiplication
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type euint64 containing the multiplication result
    function mul(euint64 lhs, euint64 rhs) internal returns (euint64) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return euint64.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.mul));
    }

    /// @notice Perform the multiplication operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted multiplication
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type euint128 containing the multiplication result
    function mul(euint128 lhs, euint128 rhs) internal returns (euint128) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return euint128.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.mul));
    }


    /// @notice Perform the less than operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type ebool containing the comparison result
    function lt(euint8 lhs, euint8 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.lt));
    }

    /// @notice Perform the less than operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type ebool containing the comparison result
    function lt(euint16 lhs, euint16 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.lt));
    }

    /// @notice Perform the less than operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type ebool containing the comparison result
    function lt(euint32 lhs, euint32 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.lt));
    }

    /// @notice Perform the less than operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type ebool containing the comparison result
    function lt(euint64 lhs, euint64 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.lt));
    }

    /// @notice Perform the less than operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type ebool containing the comparison result
    function lt(euint128 lhs, euint128 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.lt));
    }


    /// @notice Perform the division operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted division
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type euint8 containing the division result
    function div(euint8 lhs, euint8 rhs) internal returns (euint8) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return euint8.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.div));
    }

    /// @notice Perform the division operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted division
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type euint16 containing the division result
    function div(euint16 lhs, euint16 rhs) internal returns (euint16) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return euint16.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.div));
    }

    /// @notice Perform the division operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted division
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type euint32 containing the division result
    function div(euint32 lhs, euint32 rhs) internal returns (euint32) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return euint32.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.div));
    }

    /// @notice Perform the division operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted division
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type euint64 containing the division result
    function div(euint64 lhs, euint64 rhs) internal returns (euint64) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return euint64.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.div));
    }

    /// @notice Perform the division operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted division
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type euint128 containing the division result
    function div(euint128 lhs, euint128 rhs) internal returns (euint128) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return euint128.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.div));
    }


    /// @notice Perform the greater than operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type ebool containing the comparison result
    function gt(euint8 lhs, euint8 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.gt));
    }

    /// @notice Perform the greater than operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type ebool containing the comparison result
    function gt(euint16 lhs, euint16 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.gt));
    }

    /// @notice Perform the greater than operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type ebool containing the comparison result
    function gt(euint32 lhs, euint32 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.gt));
    }

    /// @notice Perform the greater than operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type ebool containing the comparison result
    function gt(euint64 lhs, euint64 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.gt));
    }

    /// @notice Perform the greater than operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type ebool containing the comparison result
    function gt(euint128 lhs, euint128 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.gt));
    }


    /// @notice Perform the greater than or equal to operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type ebool containing the comparison result
    function gte(euint8 lhs, euint8 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.gte));
    }

    /// @notice Perform the greater than or equal to operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type ebool containing the comparison result
    function gte(euint16 lhs, euint16 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.gte));
    }

    /// @notice Perform the greater than or equal to operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type ebool containing the comparison result
    function gte(euint32 lhs, euint32 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.gte));
    }

    /// @notice Perform the greater than or equal to operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type ebool containing the comparison result
    function gte(euint64 lhs, euint64 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.gte));
    }

    /// @notice Perform the greater than or equal to operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted comparison
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type ebool containing the comparison result
    function gte(euint128 lhs, euint128 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.gte));
    }


    /// @notice Perform the remainder operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted remainder calculation
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type euint8 containing the remainder result
    function rem(euint8 lhs, euint8 rhs) internal returns (euint8) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return euint8.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.rem));
    }

    /// @notice Perform the remainder operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted remainder calculation
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type euint16 containing the remainder result
    function rem(euint16 lhs, euint16 rhs) internal returns (euint16) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return euint16.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.rem));
    }

    /// @notice Perform the remainder operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted remainder calculation
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type euint32 containing the remainder result
    function rem(euint32 lhs, euint32 rhs) internal returns (euint32) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return euint32.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.rem));
    }

    /// @notice Perform the remainder operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted remainder calculation
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type euint64 containing the remainder result
    function rem(euint64 lhs, euint64 rhs) internal returns (euint64) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return euint64.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.rem));
    }

    /// @notice Perform the remainder operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted remainder calculation
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type euint128 containing the remainder result
    function rem(euint128 lhs, euint128 rhs) internal returns (euint128) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return euint128.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.rem));
    }


    /// @notice Perform the bitwise AND operation on two parameters of type ebool
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise AND
    /// @param lhs input of type ebool
    /// @param rhs second input of type ebool
    /// @return result of type ebool containing the AND result
    function and(ebool lhs, ebool rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEbool(true);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEbool(true);
        }

        return ebool.wrap(Impl.mathOp(Utils.EBOOL_TFHE, ebool.unwrap(lhs), ebool.unwrap(rhs), FunctionId.and));
    }

    /// @notice Perform the bitwise AND operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise AND
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type euint8 containing the AND result
    function and(euint8 lhs, euint8 rhs) internal returns (euint8) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return euint8.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.and));
    }

    /// @notice Perform the bitwise AND operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise AND
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type euint16 containing the AND result
    function and(euint16 lhs, euint16 rhs) internal returns (euint16) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return euint16.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.and));
    }

    /// @notice Perform the bitwise AND operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise AND
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type euint32 containing the AND result
    function and(euint32 lhs, euint32 rhs) internal returns (euint32) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return euint32.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.and));
    }

    /// @notice Perform the bitwise AND operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise AND
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type euint64 containing the AND result
    function and(euint64 lhs, euint64 rhs) internal returns (euint64) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return euint64.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.and));
    }

    /// @notice Perform the bitwise AND operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise AND
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type euint128 containing the AND result
    function and(euint128 lhs, euint128 rhs) internal returns (euint128) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return euint128.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.and));
    }


    /// @notice Perform the bitwise OR operation on two parameters of type ebool
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise OR
    /// @param lhs input of type ebool
    /// @param rhs second input of type ebool
    /// @return result of type ebool containing the OR result
    function or(ebool lhs, ebool rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEbool(true);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEbool(true);
        }

        return ebool.wrap(Impl.mathOp(Utils.EBOOL_TFHE, ebool.unwrap(lhs), ebool.unwrap(rhs), FunctionId.or));
    }

    /// @notice Perform the bitwise OR operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise OR
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type euint8 containing the OR result
    function or(euint8 lhs, euint8 rhs) internal returns (euint8) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return euint8.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.or));
    }

    /// @notice Perform the bitwise OR operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise OR
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type euint16 containing the OR result
    function or(euint16 lhs, euint16 rhs) internal returns (euint16) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return euint16.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.or));
    }

    /// @notice Perform the bitwise OR operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise OR
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type euint32 containing the OR result
    function or(euint32 lhs, euint32 rhs) internal returns (euint32) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return euint32.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.or));
    }

    /// @notice Perform the bitwise OR operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise OR
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type euint64 containing the OR result
    function or(euint64 lhs, euint64 rhs) internal returns (euint64) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return euint64.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.or));
    }

    /// @notice Perform the bitwise OR operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise OR
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type euint128 containing the OR result
    function or(euint128 lhs, euint128 rhs) internal returns (euint128) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return euint128.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.or));
    }


    /// @notice Perform the bitwise XOR operation on two parameters of type ebool
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise XOR
    /// @param lhs input of type ebool
    /// @param rhs second input of type ebool
    /// @return result of type ebool containing the XOR result
    function xor(ebool lhs, ebool rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEbool(true);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEbool(true);
        }

        return ebool.wrap(Impl.mathOp(Utils.EBOOL_TFHE, ebool.unwrap(lhs), ebool.unwrap(rhs), FunctionId.xor));
    }

    /// @notice Perform the bitwise XOR operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise XOR
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type euint8 containing the XOR result
    function xor(euint8 lhs, euint8 rhs) internal returns (euint8) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return euint8.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.xor));
    }

    /// @notice Perform the bitwise XOR operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise XOR
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type euint16 containing the XOR result
    function xor(euint16 lhs, euint16 rhs) internal returns (euint16) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return euint16.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.xor));
    }

    /// @notice Perform the bitwise XOR operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise XOR
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type euint32 containing the XOR result
    function xor(euint32 lhs, euint32 rhs) internal returns (euint32) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return euint32.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.xor));
    }

    /// @notice Perform the bitwise XOR operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise XOR
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type euint64 containing the XOR result
    function xor(euint64 lhs, euint64 rhs) internal returns (euint64) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return euint64.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.xor));
    }

    /// @notice Perform the bitwise XOR operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted bitwise XOR
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type euint128 containing the XOR result
    function xor(euint128 lhs, euint128 rhs) internal returns (euint128) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return euint128.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.xor));
    }


    /// @notice Perform the equality operation on two parameters of type ebool
    /// @dev Verifies that inputs are initialized, performs encrypted equality check
    /// @param lhs input of type ebool
    /// @param rhs second input of type ebool
    /// @return result of type ebool containing the equality result
    function eq(ebool lhs, ebool rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEbool(true);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEbool(true);
        }

        return ebool.wrap(Impl.mathOp(Utils.EBOOL_TFHE, ebool.unwrap(lhs), ebool.unwrap(rhs), FunctionId.eq));
    }

    /// @notice Perform the equality operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted equality check
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type ebool containing the equality result
    function eq(euint8 lhs, euint8 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.eq));
    }

    /// @notice Perform the equality operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted equality check
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type ebool containing the equality result
    function eq(euint16 lhs, euint16 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.eq));
    }

    /// @notice Perform the equality operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted equality check
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type ebool containing the equality result
    function eq(euint32 lhs, euint32 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.eq));
    }

    /// @notice Perform the equality operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted equality check
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type ebool containing the equality result
    function eq(euint64 lhs, euint64 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.eq));
    }

    /// @notice Perform the equality operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted equality check
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type ebool containing the equality result
    function eq(euint128 lhs, euint128 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.eq));
    }


    /// @notice Perform the equality operation on two parameters of type eaddress
    /// @dev Verifies that inputs are initialized, performs encrypted equality check
    /// @param lhs input of type eaddress
    /// @param rhs second input of type eaddress
    /// @return result of type ebool containing the equality result
    function eq(eaddress lhs, eaddress rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEaddress(address(0));
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEaddress(address(0));
        }

        return ebool.wrap(Impl.mathOp(Utils.EADDRESS_TFHE, eaddress.unwrap(lhs), eaddress.unwrap(rhs), FunctionId.eq));
    }

    /// @notice Perform the inequality operation on two parameters of type ebool
    /// @dev Verifies that inputs are initialized, performs encrypted inequality check
    /// @param lhs input of type ebool
    /// @param rhs second input of type ebool
    /// @return result of type ebool containing the inequality result
    function ne(ebool lhs, ebool rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEbool(true);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEbool(true);
        }

        return ebool.wrap(Impl.mathOp(Utils.EBOOL_TFHE, ebool.unwrap(lhs), ebool.unwrap(rhs), FunctionId.ne));
    }

    /// @notice Perform the inequality operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted inequality check
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type ebool containing the inequality result
    function ne(euint8 lhs, euint8 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.ne));
    }

    /// @notice Perform the inequality operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted inequality check
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type ebool containing the inequality result
    function ne(euint16 lhs, euint16 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.ne));
    }

    /// @notice Perform the inequality operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted inequality check
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type ebool containing the inequality result
    function ne(euint32 lhs, euint32 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.ne));
    }

    /// @notice Perform the inequality operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted inequality check
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type ebool containing the inequality result
    function ne(euint64 lhs, euint64 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.ne));
    }

    /// @notice Perform the inequality operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted inequality check
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type ebool containing the inequality result
    function ne(euint128 lhs, euint128 rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return ebool.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.ne));
    }


    /// @notice Perform the inequality operation on two parameters of type eaddress
    /// @dev Verifies that inputs are initialized, performs encrypted inequality check
    /// @param lhs input of type eaddress
    /// @param rhs second input of type eaddress
    /// @return result of type ebool containing the inequality result
    function ne(eaddress lhs, eaddress rhs) internal returns (ebool) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEaddress(address(0));
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEaddress(address(0));
        }

        return ebool.wrap(Impl.mathOp(Utils.EADDRESS_TFHE, eaddress.unwrap(lhs), eaddress.unwrap(rhs), FunctionId.ne));
    }

    /// @notice Perform the minimum operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted minimum comparison
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type euint8 containing the minimum value
    function min(euint8 lhs, euint8 rhs) internal returns (euint8) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return euint8.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.min));
    }

    /// @notice Perform the minimum operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted minimum comparison
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type euint16 containing the minimum value
    function min(euint16 lhs, euint16 rhs) internal returns (euint16) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return euint16.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.min));
    }

    /// @notice Perform the minimum operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted minimum comparison
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type euint32 containing the minimum value
    function min(euint32 lhs, euint32 rhs) internal returns (euint32) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return euint32.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.min));
    }

    /// @notice Perform the minimum operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted minimum comparison
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type euint64 containing the minimum value
    function min(euint64 lhs, euint64 rhs) internal returns (euint64) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return euint64.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.min));
    }

    /// @notice Perform the minimum operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted minimum comparison
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type euint128 containing the minimum value
    function min(euint128 lhs, euint128 rhs) internal returns (euint128) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return euint128.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.min));
    }


    /// @notice Perform the maximum operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted maximum calculation
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type euint8 containing the maximum result
    function max(euint8 lhs, euint8 rhs) internal returns (euint8) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return euint8.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.max));
    }

    /// @notice Perform the maximum operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted maximum calculation
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type euint16 containing the maximum result
    function max(euint16 lhs, euint16 rhs) internal returns (euint16) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return euint16.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.max));
    }

    /// @notice Perform the maximum operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted maximum calculation
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type euint32 containing the maximum result
    function max(euint32 lhs, euint32 rhs) internal returns (euint32) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return euint32.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.max));
    }

    /// @notice Perform the maximum operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted maximum comparison
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type euint64 containing the maximum value
    function max(euint64 lhs, euint64 rhs) internal returns (euint64) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return euint64.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.max));
    }

    /// @notice Perform the maximum operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted maximum comparison
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type euint128 containing the maximum value
    function max(euint128 lhs, euint128 rhs) internal returns (euint128) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return euint128.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.max));
    }


    /// @notice Perform the shift left operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted left shift
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type euint8 containing the left shift result
    function shl(euint8 lhs, euint8 rhs) internal returns (euint8) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return euint8.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.shl));
    }

    /// @notice Perform the shift left operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted left shift
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type euint16 containing the left shift result
    function shl(euint16 lhs, euint16 rhs) internal returns (euint16) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return euint16.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.shl));
    }

    /// @notice Perform the shift left operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted left shift
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type euint32 containing the left shift result
    function shl(euint32 lhs, euint32 rhs) internal returns (euint32) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return euint32.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.shl));
    }

    /// @notice Perform the shift left operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted left shift
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type euint64 containing the left shift result
    function shl(euint64 lhs, euint64 rhs) internal returns (euint64) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return euint64.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.shl));
    }

    /// @notice Perform the shift left operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted left shift
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type euint128 containing the left shift result
    function shl(euint128 lhs, euint128 rhs) internal returns (euint128) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return euint128.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.shl));
    }


    /// @notice Perform the shift right operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted right shift
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type euint8 containing the right shift result
    function shr(euint8 lhs, euint8 rhs) internal returns (euint8) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return euint8.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.shr));
    }

    /// @notice Perform the shift right operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted right shift
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type euint16 containing the right shift result
    function shr(euint16 lhs, euint16 rhs) internal returns (euint16) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return euint16.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.shr));
    }

    /// @notice Perform the shift right operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted right shift
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type euint32 containing the right shift result
    function shr(euint32 lhs, euint32 rhs) internal returns (euint32) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return euint32.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.shr));
    }

    /// @notice Perform the shift right operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted right shift
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type euint64 containing the right shift result
    function shr(euint64 lhs, euint64 rhs) internal returns (euint64) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return euint64.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.shr));
    }

    /// @notice Perform the shift right operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted right shift
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type euint128 containing the right shift result
    function shr(euint128 lhs, euint128 rhs) internal returns (euint128) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return euint128.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.shr));
    }


    /// @notice Perform the rol operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted left rotation
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type euint8 containing the left rotation result
    function rol(euint8 lhs, euint8 rhs) internal returns (euint8) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return euint8.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.rol));
    }

    /// @notice Perform the rotate left operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted left rotation
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type euint16 containing the left rotation result
    function rol(euint16 lhs, euint16 rhs) internal returns (euint16) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return euint16.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.rol));
    }

    /// @notice Perform the rotate left operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted left rotation
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type euint32 containing the left rotation result
    function rol(euint32 lhs, euint32 rhs) internal returns (euint32) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return euint32.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.rol));
    }

    /// @notice Perform the rotate left operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted left rotation
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type euint64 containing the left rotation result
    function rol(euint64 lhs, euint64 rhs) internal returns (euint64) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return euint64.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.rol));
    }

    /// @notice Perform the rotate left operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted left rotation
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type euint128 containing the left rotation result
    function rol(euint128 lhs, euint128 rhs) internal returns (euint128) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return euint128.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.rol));
    }


    /// @notice Perform the rotate right operation on two parameters of type euint8
    /// @dev Verifies that inputs are initialized, performs encrypted right rotation
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return result of type euint8 containing the right rotation result
    function ror(euint8 lhs, euint8 rhs) internal returns (euint8) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint8(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint8(0);
        }

        return euint8.wrap(Impl.mathOp(Utils.EUINT8_TFHE, euint8.unwrap(lhs), euint8.unwrap(rhs), FunctionId.ror));
    }

    /// @notice Perform the rotate right operation on two parameters of type euint16
    /// @dev Verifies that inputs are initialized, performs encrypted right rotation
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return result of type euint16 containing the right rotation result
    function ror(euint16 lhs, euint16 rhs) internal returns (euint16) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint16(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint16(0);
        }

        return euint16.wrap(Impl.mathOp(Utils.EUINT16_TFHE, euint16.unwrap(lhs), euint16.unwrap(rhs), FunctionId.ror));
    }

    /// @notice Perform the rotate right operation on two parameters of type euint32
    /// @dev Verifies that inputs are initialized, performs encrypted right rotation
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return result of type euint32 containing the right rotation result
    function ror(euint32 lhs, euint32 rhs) internal returns (euint32) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint32(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint32(0);
        }

        return euint32.wrap(Impl.mathOp(Utils.EUINT32_TFHE, euint32.unwrap(lhs), euint32.unwrap(rhs), FunctionId.ror));
    }

    /// @notice Perform the rotate right operation on two parameters of type euint64
    /// @dev Verifies that inputs are initialized, performs encrypted right rotation
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return result of type euint64 containing the right rotation result
    function ror(euint64 lhs, euint64 rhs) internal returns (euint64) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint64(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint64(0);
        }

        return euint64.wrap(Impl.mathOp(Utils.EUINT64_TFHE, euint64.unwrap(lhs), euint64.unwrap(rhs), FunctionId.ror));
    }

    /// @notice Perform the rotate right operation on two parameters of type euint128
    /// @dev Verifies that inputs are initialized, performs encrypted right rotation
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return result of type euint128 containing the right rotation result
    function ror(euint128 lhs, euint128 rhs) internal returns (euint128) {
        if (!Common.isInitialized(lhs)) {
            lhs = asEuint128(0);
        }
        if (!Common.isInitialized(rhs)) {
            rhs = asEuint128(0);
        }

        return euint128.wrap(Impl.mathOp(Utils.EUINT128_TFHE, euint128.unwrap(lhs), euint128.unwrap(rhs), FunctionId.ror));
    }

    /// @notice Gets the decrypted value from a previously decrypted ebool ciphertext
    /// @dev This function will revert if the ciphertext is not yet decrypted. Use getDecryptResultSafe for a non-reverting version.
    /// @param input1 The ebool ciphertext to get the decrypted value from
    /// @return The decrypted boolean value
    function getDecryptResult(ebool input1) internal view returns (bool) {
        uint256 result = Impl.getDecryptResult(ebool.unwrap(input1));
        return result != 0;
    }

    /// @notice Gets the decrypted value from a previously decrypted euint8 ciphertext
    /// @dev This function will revert if the ciphertext is not yet decrypted. Use getDecryptResultSafe for a non-reverting version.
    /// @param input1 The euint8 ciphertext to get the decrypted value from
    /// @return The decrypted uint8 value
    function getDecryptResult(euint8 input1) internal view returns (uint8) {
        return uint8(Impl.getDecryptResult(euint8.unwrap(input1)));
    }

    /// @notice Gets the decrypted value from a previously decrypted euint16 ciphertext
    /// @dev This function will revert if the ciphertext is not yet decrypted. Use getDecryptResultSafe for a non-reverting version.
    /// @param input1 The euint16 ciphertext to get the decrypted value from
    /// @return The decrypted uint16 value
    function getDecryptResult(euint16 input1) internal view returns (uint16) {
        return uint16(Impl.getDecryptResult(euint16.unwrap(input1)));
    }

    /// @notice Gets the decrypted value from a previously decrypted euint32 ciphertext
    /// @dev This function will revert if the ciphertext is not yet decrypted. Use getDecryptResultSafe for a non-reverting version.
    /// @param input1 The euint32 ciphertext to get the decrypted value from
    /// @return The decrypted uint32 value
    function getDecryptResult(euint32 input1) internal view returns (uint32) {
        return uint32(Impl.getDecryptResult(euint32.unwrap(input1)));
    }

    /// @notice Gets the decrypted value from a previously decrypted euint64 ciphertext
    /// @dev This function will revert if the ciphertext is not yet decrypted. Use getDecryptResultSafe for a non-reverting version.
    /// @param input1 The euint64 ciphertext to get the decrypted value from
    /// @return The decrypted uint64 value
    function getDecryptResult(euint64 input1) internal view returns (uint64) {
        return uint64(Impl.getDecryptResult(euint64.unwrap(input1)));
    }

    /// @notice Gets the decrypted value from a previously decrypted euint128 ciphertext
    /// @dev This function will revert if the ciphertext is not yet decrypted. Use getDecryptResultSafe for a non-reverting version.
    /// @param input1 The euint128 ciphertext to get the decrypted value from
    /// @return The decrypted uint128 value
    function getDecryptResult(euint128 input1) internal view returns (uint128) {
        return uint128(Impl.getDecryptResult(euint128.unwrap(input1)));
    }

    /// @notice Gets the decrypted value from a previously decrypted eaddress ciphertext
    /// @dev This function will revert if the ciphertext is not yet decrypted. Use getDecryptResultSafe for a non-reverting version.
    /// @param input1 The eaddress ciphertext to get the decrypted value from
    /// @return The decrypted address value
    function getDecryptResult(eaddress input1) internal view returns (address) {
        return address(uint160(Impl.getDecryptResult(eaddress.unwrap(input1))));
    }

    /// @notice Gets the decrypted value from a previously decrypted raw ciphertext
    /// @dev This function will revert if the ciphertext is not yet decrypted. Use getDecryptResultSafe for a non-reverting version.
    /// @param input1 The raw ciphertext to get the decrypted value from
    /// @return The decrypted uint256 value
    function getDecryptResult(bytes32 input1) internal view returns (uint256) {
        return Impl.getDecryptResult(input1);
    }

    /// @notice Safely gets the decrypted value from an ebool ciphertext
    /// @dev Returns the decrypted value and a flag indicating whether the decryption has finished
    /// @param input1 The ebool ciphertext to get the decrypted value from
    /// @return result The decrypted boolean value
    /// @return decrypted Flag indicating if the value was successfully decrypted
    function getDecryptResultSafe(ebool input1) internal view returns (bool result, bool decrypted) {
        (uint256 _result, bool _decrypted) = Impl.getDecryptResultSafe(ebool.unwrap(input1));
        return (_result != 0, _decrypted);
    }

    /// @notice Safely gets the decrypted value from a euint8 ciphertext
    /// @dev Returns the decrypted value and a flag indicating whether the decryption has finished
    /// @param input1 The euint8 ciphertext to get the decrypted value from
    /// @return result The decrypted uint8 value
    /// @return decrypted Flag indicating if the value was successfully decrypted
    function getDecryptResultSafe(euint8 input1) internal view returns (uint8 result, bool decrypted) {
        (uint256 _result, bool _decrypted) = Impl.getDecryptResultSafe(euint8.unwrap(input1));
        return (uint8(_result), _decrypted);
    }

    /// @notice Safely gets the decrypted value from a euint16 ciphertext
    /// @dev Returns the decrypted value and a flag indicating whether the decryption has finished
    /// @param input1 The euint16 ciphertext to get the decrypted value from
    /// @return result The decrypted uint16 value
    /// @return decrypted Flag indicating if the value was successfully decrypted
    function getDecryptResultSafe(euint16 input1) internal view returns (uint16 result, bool decrypted) {
        (uint256 _result, bool _decrypted) = Impl.getDecryptResultSafe(euint16.unwrap(input1));
        return (uint16(_result), _decrypted);
    }

    /// @notice Safely gets the decrypted value from a euint32 ciphertext
    /// @dev Returns the decrypted value and a flag indicating whether the decryption has finished
    /// @param input1 The euint32 ciphertext to get the decrypted value from
    /// @return result The decrypted uint32 value
    /// @return decrypted Flag indicating if the value was successfully decrypted
    function getDecryptResultSafe(euint32 input1) internal view returns (uint32 result, bool decrypted) {
        (uint256 _result, bool _decrypted) = Impl.getDecryptResultSafe(euint32.unwrap(input1));
        return (uint32(_result), _decrypted);
    }

    /// @notice Safely gets the decrypted value from a euint64 ciphertext
    /// @dev Returns the decrypted value and a flag indicating whether the decryption has finished
    /// @param input1 The euint64 ciphertext to get the decrypted value from
    /// @return result The decrypted uint64 value
    /// @return decrypted Flag indicating if the value was successfully decrypted
    function getDecryptResultSafe(euint64 input1) internal view returns (uint64 result, bool decrypted) {
        (uint256 _result, bool _decrypted) = Impl.getDecryptResultSafe(euint64.unwrap(input1));
        return (uint64(_result), _decrypted);
    }

    /// @notice Safely gets the decrypted value from a euint128 ciphertext
    /// @dev Returns the decrypted value and a flag indicating whether the decryption has finished
    /// @param input1 The euint128 ciphertext to get the decrypted value from
    /// @return result The decrypted uint128 value
    /// @return decrypted Flag indicating if the value was successfully decrypted
    function getDecryptResultSafe(euint128 input1) internal view returns (uint128 result, bool decrypted) {
        (uint256 _result, bool _decrypted) = Impl.getDecryptResultSafe(euint128.unwrap(input1));
        return (uint128(_result), _decrypted);
    }


    /// @notice Safely gets the decrypted value from an eaddress ciphertext
    /// @dev Returns the decrypted value and a flag indicating whether the decryption has finished
    /// @param input1 The eaddress ciphertext to get the decrypted value from
    /// @return result The decrypted address value
    /// @return decrypted Flag indicating if the value was successfully decrypted
    function getDecryptResultSafe(eaddress input1) internal view returns (address result, bool decrypted) {
        (uint256 _result, bool _decrypted) = Impl.getDecryptResultSafe(eaddress.unwrap(input1));
        return (address(uint160(_result)), _decrypted);
    }

    /// @notice Safely gets the decrypted value from a raw ciphertext
    /// @dev Returns the decrypted value and a flag indicating whether the decryption has finished
    /// @param input1 The raw ciphertext to get the decrypted value from
    /// @return result The decrypted uint256 value
    /// @return decrypted Flag indicating if the value was successfully decrypted
    function getDecryptResultSafe(bytes32 input1) internal view returns (uint256 result, bool decrypted) {
        (uint256 _result, bool _decrypted) = Impl.getDecryptResultSafe(input1);
        return (_result, _decrypted);
    }

    /// @notice Performs a multiplexer operation between two ebool values based on a selector
    /// @dev If input1 is true, returns input2, otherwise returns input3. All inputs are initialized to defaults if not set.
    /// @param input1 The selector of type ebool
    /// @param input2 First choice of type ebool
    /// @param input3 Second choice of type ebool
    /// @return result of type ebool containing the selected value
    function select(ebool input1, ebool input2, ebool input3) internal returns (ebool) {
        if (!Common.isInitialized(input1)) {
            input1 = asEbool(false);
        }
        if (!Common.isInitialized(input2)) {
            input2 = asEbool(false);
        }
        if (!Common.isInitialized(input3)) {
            input3 = asEbool(false);
        }

        return ebool.wrap(Impl.select(Utils.EBOOL_TFHE, input1, ebool.unwrap(input2), ebool.unwrap(input3)));
    }

    /// @notice Performs a multiplexer operation between two euint8 values based on a selector
    /// @dev If input1 is true, returns input2, otherwise returns input3. All inputs are initialized to defaults if not set.
    /// @param input1 The selector of type ebool
    /// @param input2 First choice of type euint8
    /// @param input3 Second choice of type euint8
    /// @return result of type euint8 containing the selected value
    function select(ebool input1, euint8 input2, euint8 input3) internal returns (euint8) {
        if (!Common.isInitialized(input1)) {
            input1 = asEbool(false);
        }
        if (!Common.isInitialized(input2)) {
            input2 = asEuint8(0);
        }
        if (!Common.isInitialized(input3)) {
            input3 = asEuint8(0);
        }

        return euint8.wrap(Impl.select(Utils.EUINT8_TFHE, input1, euint8.unwrap(input2), euint8.unwrap(input3)));
    }

    /// @notice Performs a multiplexer operation between two euint16 values based on a selector
    /// @dev If input1 is true, returns input2, otherwise returns input3. All inputs are initialized to defaults if not set.
    /// @param input1 The selector of type ebool
    /// @param input2 First choice of type euint16
    /// @param input3 Second choice of type euint16
    /// @return result of type euint16 containing the selected value
    function select(ebool input1, euint16 input2, euint16 input3) internal returns (euint16) {
        if (!Common.isInitialized(input1)) {
            input1 = asEbool(false);
        }
        if (!Common.isInitialized(input2)) {
            input2 = asEuint16(0);
        }
        if (!Common.isInitialized(input3)) {
            input3 = asEuint16(0);
        }

        return euint16.wrap(Impl.select(Utils.EUINT16_TFHE, input1, euint16.unwrap(input2), euint16.unwrap(input3)));
    }

    /// @notice Performs a multiplexer operation between two euint32 values based on a selector
    /// @dev If input1 is true, returns input2, otherwise returns input3. All inputs are initialized to defaults if not set.
    /// @param input1 The selector of type ebool
    /// @param input2 First choice of type euint32
    /// @param input3 Second choice of type euint32
    /// @return result of type euint32 containing the selected value
    function select(ebool input1, euint32 input2, euint32 input3) internal returns (euint32) {
        if (!Common.isInitialized(input1)) {
            input1 = asEbool(false);
        }
        if (!Common.isInitialized(input2)) {
            input2 = asEuint32(0);
        }
        if (!Common.isInitialized(input3)) {
            input3 = asEuint32(0);
        }

        return euint32.wrap(Impl.select(Utils.EUINT32_TFHE, input1, euint32.unwrap(input2), euint32.unwrap(input3)));
    }

    /// @notice Performs a multiplexer operation between two euint64 values based on a selector
    /// @dev If input1 is true, returns input2, otherwise returns input3. All inputs are initialized to defaults if not set.
    /// @param input1 The selector of type ebool
    /// @param input2 First choice of type euint64
    /// @param input3 Second choice of type euint64
    /// @return result of type euint64 containing the selected value
    function select(ebool input1, euint64 input2, euint64 input3) internal returns (euint64) {
        if (!Common.isInitialized(input1)) {
            input1 = asEbool(false);
        }
        if (!Common.isInitialized(input2)) {
            input2 = asEuint64(0);
        }
        if (!Common.isInitialized(input3)) {
            input3 = asEuint64(0);
        }

        return euint64.wrap(Impl.select(Utils.EUINT64_TFHE, input1, euint64.unwrap(input2), euint64.unwrap(input3)));
    }

    /// @notice Performs a multiplexer operation between two euint128 values based on a selector
    /// @dev If input1 is true, returns input2, otherwise returns input3. All inputs are initialized to defaults if not set.
    /// @param input1 The selector of type ebool
    /// @param input2 First choice of type euint128
    /// @param input3 Second choice of type euint128
    /// @return result of type euint128 containing the selected value
    function select(ebool input1, euint128 input2, euint128 input3) internal returns (euint128) {
        if (!Common.isInitialized(input1)) {
            input1 = asEbool(false);
        }
        if (!Common.isInitialized(input2)) {
            input2 = asEuint128(0);
        }
        if (!Common.isInitialized(input3)) {
            input3 = asEuint128(0);
        }

        return euint128.wrap(Impl.select(Utils.EUINT128_TFHE, input1, euint128.unwrap(input2), euint128.unwrap(input3)));
    }


    /// @notice Performs a multiplexer operation between two eaddress values based on a selector
    /// @dev If input1 is true, returns input2, otherwise returns input3. All inputs are initialized to defaults if not set.
    /// @param input1 The selector of type ebool
    /// @param input2 First choice of type eaddress
    /// @param input3 Second choice of type eaddress
    /// @return result of type eaddress containing the selected value
    function select(ebool input1, eaddress input2, eaddress input3) internal returns (eaddress) {
        if (!Common.isInitialized(input1)) {
            input1 = asEbool(false);
        }
        if (!Common.isInitialized(input2)) {
            input2 = asEaddress(address(0));
        }
        if (!Common.isInitialized(input3)) {
            input3 = asEaddress(address(0));
        }

        return eaddress.wrap(Impl.select(Utils.EADDRESS_TFHE, input1, eaddress.unwrap(input2), eaddress.unwrap(input3)));
    }

    /// @notice Performs the not operation on a ciphertext
    /// @dev Verifies that the input value matches a valid ciphertext.
    /// @param input1 the input ciphertext
    function not(ebool input1) internal returns (ebool) {
        if (!Common.isInitialized(input1)) {
            input1 = asEbool(false);
        }

        return ebool.wrap(Impl.not(Utils.EBOOL_TFHE, ebool.unwrap(input1)));
    }

    /// @notice Performs the not operation on a ciphertext
    /// @dev Verifies that the input value matches a valid ciphertext.
    /// @param input1 the input ciphertext
    function not(euint8 input1) internal returns (euint8) {
        if (!Common.isInitialized(input1)) {
            input1 = asEuint8(0);
        }

        return euint8.wrap(Impl.not(Utils.EUINT8_TFHE, euint8.unwrap(input1)));
    }
    /// @notice Performs the not operation on a ciphertext
    /// @dev Verifies that the input value matches a valid ciphertext.
    /// @param input1 the input ciphertext
    function not(euint16 input1) internal returns (euint16) {
        if (!Common.isInitialized(input1)) {
            input1 = asEuint16(0);
        }

        return euint16.wrap(Impl.not(Utils.EUINT16_TFHE, euint16.unwrap(input1)));
    }
    /// @notice Performs the not operation on a ciphertext
    /// @dev Verifies that the input value matches a valid ciphertext.
    /// @param input1 the input ciphertext
    function not(euint32 input1) internal returns (euint32) {
        if (!Common.isInitialized(input1)) {
            input1 = asEuint32(0);
        }

        return euint32.wrap(Impl.not(Utils.EUINT32_TFHE, euint32.unwrap(input1)));
    }

    /// @notice Performs the bitwise NOT operation on an encrypted 64-bit unsigned integer
    /// @dev Verifies that the input is initialized, defaulting to 0 if not.
    ///      The operation inverts all bits of the input value.
    /// @param input1 The input ciphertext to negate
    /// @return An euint64 containing the bitwise NOT of the input
    function not(euint64 input1) internal returns (euint64) {
        if (!Common.isInitialized(input1)) {
            input1 = asEuint64(0);
        }

        return euint64.wrap(Impl.not(Utils.EUINT64_TFHE, euint64.unwrap(input1)));
    }

    /// @notice Performs the bitwise NOT operation on an encrypted 128-bit unsigned integer
    /// @dev Verifies that the input is initialized, defaulting to 0 if not.
    ///      The operation inverts all bits of the input value.
    /// @param input1 The input ciphertext to negate
    /// @return An euint128 containing the bitwise NOT of the input
    function not(euint128 input1) internal returns (euint128) {
        if (!Common.isInitialized(input1)) {
            input1 = asEuint128(0);
        }

        return euint128.wrap(Impl.not(Utils.EUINT128_TFHE, euint128.unwrap(input1)));
    }


    /// @notice Performs the square operation on an encrypted 8-bit unsigned integer
    /// @dev Verifies that the input is initialized, defaulting to 0 if not.
    ///      Note: The result may overflow if input * input exceeds 8 bits.
    /// @param input1 The input ciphertext to square
    /// @return An euint8 containing the square of the input
    function square(euint8 input1) internal returns (euint8) {
        if (!Common.isInitialized(input1)) {
            input1 = asEuint8(0);
        }

        return euint8.wrap(Impl.square(Utils.EUINT8_TFHE, euint8.unwrap(input1)));
    }

    /// @notice Performs the square operation on an encrypted 16-bit unsigned integer
    /// @dev Verifies that the input is initialized, defaulting to 0 if not.
    ///      Note: The result may overflow if input * input exceeds 16 bits.
    /// @param input1 The input ciphertext to square
    /// @return An euint16 containing the square of the input
    function square(euint16 input1) internal returns (euint16) {
        if (!Common.isInitialized(input1)) {
            input1 = asEuint16(0);
        }

        return euint16.wrap(Impl.square(Utils.EUINT16_TFHE, euint16.unwrap(input1)));
    }

    /// @notice Performs the square operation on an encrypted 32-bit unsigned integer
    /// @dev Verifies that the input is initialized, defaulting to 0 if not.
    ///      Note: The result may overflow if input * input exceeds 32 bits.
    /// @param input1 The input ciphertext to square
    /// @return An euint32 containing the square of the input
    function square(euint32 input1) internal returns (euint32) {
        if (!Common.isInitialized(input1)) {
            input1 = asEuint32(0);
        }

        return euint32.wrap(Impl.square(Utils.EUINT32_TFHE, euint32.unwrap(input1)));
    }

    /// @notice Performs the square operation on an encrypted 64-bit unsigned integer
    /// @dev Verifies that the input is initialized, defaulting to 0 if not.
    ///      Note: The result may overflow if input * input exceeds 64 bits.
    /// @param input1 The input ciphertext to square
    /// @return An euint64 containing the square of the input
    function square(euint64 input1) internal returns (euint64) {
        if (!Common.isInitialized(input1)) {
            input1 = asEuint64(0);
        }

        return euint64.wrap(Impl.square(Utils.EUINT64_TFHE, euint64.unwrap(input1)));
    }

    /// @notice Performs the square operation on an encrypted 128-bit unsigned integer
    /// @dev Verifies that the input is initialized, defaulting to 0 if not.
    ///      Note: The result may overflow if input * input exceeds 128 bits.
    /// @param input1 The input ciphertext to square
    /// @return An euint128 containing the square of the input
    function square(euint128 input1) internal returns (euint128) {
        if (!Common.isInitialized(input1)) {
            input1 = asEuint128(0);
        }

        return euint128.wrap(Impl.square(Utils.EUINT128_TFHE, euint128.unwrap(input1)));
    }

    /// @notice Generates a random value of a euint8 type for provided securityZone
    /// @dev Generates a cryptographically secure random 8-bit unsigned integer in encrypted form.
    ///      The generated value is fully encrypted and cannot be predicted by any party.
    /// @param securityZone The security zone identifier to use for random value generation.
    /// @return A randomly generated encrypted 8-bit unsigned integer (euint8)
    function randomEuint8(int32 securityZone) internal returns (euint8) {
        return euint8.wrap(Impl.random(Utils.EUINT8_TFHE, 0, securityZone));
    }
    /// @notice Generates a random value of a euint8 type
    /// @dev Generates a cryptographically secure random 8-bit unsigned integer in encrypted form
    ///      using the default security zone (0). The generated value is fully encrypted and
    ///      cannot be predicted by any party.
    /// @return A randomly generated encrypted 8-bit unsigned integer (euint8)
    function randomEuint8() internal returns (euint8) {
        return randomEuint8(0);
    }
    /// @notice Generates a random value of a euint16 type for provided securityZone
    /// @dev Generates a cryptographically secure random 16-bit unsigned integer in encrypted form.
    ///      The generated value is fully encrypted and cannot be predicted by any party.
    /// @param securityZone The security zone identifier to use for random value generation.
    /// @return A randomly generated encrypted 16-bit unsigned integer (euint16)
    function randomEuint16(int32 securityZone) internal returns (euint16) {
        return euint16.wrap(Impl.random(Utils.EUINT16_TFHE, 0, securityZone));
    }
    /// @notice Generates a random value of a euint16 type
    /// @dev Generates a cryptographically secure random 16-bit unsigned integer in encrypted form
    ///      using the default security zone (0). The generated value is fully encrypted and
    ///      cannot be predicted by any party.
    /// @return A randomly generated encrypted 16-bit unsigned integer (euint16)
    function randomEuint16() internal returns (euint16) {
        return randomEuint16(0);
    }
    /// @notice Generates a random value of a euint32 type for provided securityZone
    /// @dev Generates a cryptographically secure random 32-bit unsigned integer in encrypted form.
    ///      The generated value is fully encrypted and cannot be predicted by any party.
    /// @param securityZone The security zone identifier to use for random value generation.
    /// @return A randomly generated encrypted 32-bit unsigned integer (euint32)
    function randomEuint32(int32 securityZone) internal returns (euint32) {
        return euint32.wrap(Impl.random(Utils.EUINT32_TFHE, 0, securityZone));
    }
    /// @notice Generates a random value of a euint32 type
    /// @dev Generates a cryptographically secure random 32-bit unsigned integer in encrypted form
    ///      using the default security zone (0). The generated value is fully encrypted and
    ///      cannot be predicted by any party.
    /// @return A randomly generated encrypted 32-bit unsigned integer (euint32)
    function randomEuint32() internal returns (euint32) {
        return randomEuint32(0);
    }
    /// @notice Generates a random value of a euint64 type for provided securityZone
    /// @dev Generates a cryptographically secure random 64-bit unsigned integer in encrypted form.
    ///      The generated value is fully encrypted and cannot be predicted by any party.
    /// @param securityZone The security zone identifier to use for random value generation.
    /// @return A randomly generated encrypted 64-bit unsigned integer (euint64)
    function randomEuint64(int32 securityZone) internal returns (euint64) {
        return euint64.wrap(Impl.random(Utils.EUINT64_TFHE, 0, securityZone));
    }
    /// @notice Generates a random value of a euint64 type
    /// @dev Generates a cryptographically secure random 64-bit unsigned integer in encrypted form
    ///      using the default security zone (0). The generated value is fully encrypted and
    ///      cannot be predicted by any party.
    /// @return A randomly generated encrypted 64-bit unsigned integer (euint64)
    function randomEuint64() internal returns (euint64) {
        return randomEuint64(0);
    }
    /// @notice Generates a random value of a euint128 type for provided securityZone
    /// @dev Generates a cryptographically secure random 128-bit unsigned integer in encrypted form.
    ///      The generated value is fully encrypted and cannot be predicted by any party.
    /// @param securityZone The security zone identifier to use for random value generation.
    /// @return A randomly generated encrypted 128-bit unsigned integer (euint128)
    function randomEuint128(int32 securityZone) internal returns (euint128) {
        return euint128.wrap(Impl.random(Utils.EUINT128_TFHE, 0, securityZone));
    }
    /// @notice Generates a random value of a euint128 type
    /// @dev Generates a cryptographically secure random 128-bit unsigned integer in encrypted form
    ///      using the default security zone (0). The generated value is fully encrypted and
    ///      cannot be predicted by any party.
    /// @return A randomly generated encrypted 128-bit unsigned integer (euint128)
    function randomEuint128() internal returns (euint128) {
        return randomEuint128(0);
    }

    /// @notice Verifies and converts an ABI-encoded encrypted input to an ebool encrypted type
    /// @dev Verifies the input signature and security parameters before converting to the encrypted type
    /// @param value The ABI-encoded (ctHash, securityZone, utype, signature) input
    /// @return An ebool containing the verified encrypted value
    function asEbool(bytes memory value) internal returns (ebool) {
        EncryptedInput memory input = Utils.inputFromBytes(value, Utils.EBOOL_TFHE);
        return ebool.wrap(Impl.verifyInput(input));
    }

    /// @notice Verifies and converts an externalEbool handle and its proof to an ebool encrypted type
    /// @dev Verifies the input signature and security parameters before converting to the encrypted type
    /// @param hash The hash of the encrypted input
    /// @param proof The proof containing the signature
    /// @return An ebool containing the verified encrypted value
    function asEbool(externalEbool hash, bytes memory proof) internal returns (ebool) {
        EncryptedInput memory input = Utils.inputFromHashAndProof(externalEbool.unwrap(hash), proof, Utils.EBOOL_TFHE);
        return ebool.wrap(Impl.verifyInput(input));
    }

    /// @notice Verifies and converts an ABI-encoded encrypted input to an euint8 encrypted type
    /// @dev Verifies the input signature and security parameters before converting to the encrypted type
    /// @param value The ABI-encoded (ctHash, securityZone, utype, signature) input
    /// @return An euint8 containing the verified encrypted value
    function asEuint8(bytes memory value) internal returns (euint8) {
        EncryptedInput memory input = Utils.inputFromBytes(value, Utils.EUINT8_TFHE);
        return euint8.wrap(Impl.verifyInput(input));
    }

    /// @notice Verifies and converts an externalEuint8 handle and its proof to an euint8 encrypted type
    /// @dev Verifies the input signature and security parameters before converting to the encrypted type
    /// @param hash The hash of the encrypted input
    /// @param proof The proof containing the signature
    /// @return An euint8 containing the verified encrypted value
    function asEuint8(externalEuint8 hash, bytes memory proof) internal returns (euint8) {
        EncryptedInput memory input = Utils.inputFromHashAndProof(externalEuint8.unwrap(hash), proof, Utils.EUINT8_TFHE);
        return euint8.wrap(Impl.verifyInput(input));
    }

    /// @notice Verifies and converts an ABI-encoded encrypted input to an euint16 encrypted type
    /// @dev Verifies the input signature and security parameters before converting to the encrypted type
    /// @param value The ABI-encoded (ctHash, securityZone, utype, signature) input
    /// @return An euint16 containing the verified encrypted value
    function asEuint16(bytes memory value) internal returns (euint16) {
        EncryptedInput memory input = Utils.inputFromBytes(value, Utils.EUINT16_TFHE);
        return euint16.wrap(Impl.verifyInput(input));
    }

    /// @notice Verifies and converts an externalEuint16 handle and its proof to an euint16 encrypted type
    /// @dev Verifies the input signature and security parameters before converting to the encrypted type
    /// @param hash The hash of the encrypted input
    /// @param proof The proof containing the signature
    /// @return An euint16 containing the verified encrypted value
    function asEuint16(externalEuint16 hash, bytes memory proof) internal returns (euint16) {
        EncryptedInput memory input = Utils.inputFromHashAndProof(externalEuint16.unwrap(hash), proof, Utils.EUINT16_TFHE);
        return euint16.wrap(Impl.verifyInput(input));
    }

    /// @notice Verifies and converts an ABI-encoded encrypted input to an euint32 encrypted type
    /// @dev Verifies the input signature and security parameters before converting to the encrypted type
    /// @param value The ABI-encoded (ctHash, securityZone, utype, signature) input
    /// @return An euint32 containing the verified encrypted value
    function asEuint32(bytes memory value) internal returns (euint32) {
        EncryptedInput memory input = Utils.inputFromBytes(value, Utils.EUINT32_TFHE);
        return euint32.wrap(Impl.verifyInput(input));
    }

    /// @notice Verifies and converts an externalEuint32 handle and its proof to an euint32 encrypted type
    /// @dev Verifies the input signature and security parameters before converting to the encrypted type
    /// @param hash The hash of the encrypted input
    /// @param proof The proof containing the signature
    /// @return An euint32 containing the verified encrypted value
    function asEuint32(externalEuint32 hash, bytes memory proof) internal returns (euint32) {
        EncryptedInput memory input = Utils.inputFromHashAndProof(externalEuint32.unwrap(hash), proof, Utils.EUINT32_TFHE);
        return euint32.wrap(Impl.verifyInput(input));
    }

    /// @notice Verifies and converts an ABI-encoded encrypted input to an euint64 encrypted type
    /// @dev Verifies the input signature and security parameters before converting to the encrypted type
    /// @param value The ABI-encoded (ctHash, securityZone, utype, signature) input
    /// @return An euint64 containing the verified encrypted value
    function asEuint64(bytes memory value) internal returns (euint64) {
        EncryptedInput memory input = Utils.inputFromBytes(value, Utils.EUINT64_TFHE);
        return euint64.wrap(Impl.verifyInput(input));
    }

    /// @notice Verifies and converts an externalEuint64 handle and its proof to an euint64 encrypted type
    /// @dev Verifies the input signature and security parameters before converting to the encrypted type
    /// @param hash The hash of the encrypted input
    /// @param proof The proof containing the signature
    /// @return An euint64 containing the verified encrypted value
    function asEuint64(externalEuint64 hash, bytes memory proof) internal returns (euint64) {
        EncryptedInput memory input = Utils.inputFromHashAndProof(externalEuint64.unwrap(hash), proof, Utils.EUINT64_TFHE);
        return euint64.wrap(Impl.verifyInput(input));
    }

    /// @notice Verifies and converts an ABI-encoded encrypted input to an euint128 encrypted type
    /// @dev Verifies the input signature and security parameters before converting to the encrypted type
    /// @param value The ABI-encoded (ctHash, securityZone, utype, signature) input
    /// @return An euint128 containing the verified encrypted value
    function asEuint128(bytes memory value) internal returns (euint128) {
        EncryptedInput memory input = Utils.inputFromBytes(value, Utils.EUINT128_TFHE);
        return euint128.wrap(Impl.verifyInput(input));
    }

    /// @notice Verifies and converts an externalEuint128 handle and its proof to an euint128 encrypted type
    /// @dev Verifies the input signature and security parameters before converting to the encrypted type
    /// @param hash The hash of the encrypted input
    /// @param proof The proof containing the signature
    /// @return An euint128 containing the verified encrypted value
    function asEuint128(externalEuint128 hash, bytes memory proof) internal returns (euint128) {
        EncryptedInput memory input = Utils.inputFromHashAndProof(externalEuint128.unwrap(hash), proof, Utils.EUINT128_TFHE);
        return euint128.wrap(Impl.verifyInput(input));
    }

    /// @notice Verifies and converts an ABI-encoded encrypted input to an eaddress encrypted type
    /// @dev Verifies the input signature and security parameters before converting to the encrypted type
    /// @param value The ABI-encoded (ctHash, securityZone, utype, signature) input
    /// @return An eaddress containing the verified encrypted value
    function asEaddress(bytes memory value) internal returns (eaddress) {
        EncryptedInput memory input = Utils.inputFromBytes(value, Utils.EADDRESS_TFHE);
        return eaddress.wrap(Impl.verifyInput(input));
    }

    /// @notice Verifies and converts an externalEaddress handle and its proof to an eaddress encrypted type
    /// @dev Verifies the input signature and security parameters before converting to the encrypted type
    /// @param hash The hash of the encrypted input
    /// @param proof The proof containing the signature
    /// @return An eaddress containing the verified encrypted value
    function asEaddress(externalEaddress hash, bytes memory proof) internal returns (eaddress) {
        EncryptedInput memory input = Utils.inputFromHashAndProof(externalEaddress.unwrap(hash), proof, Utils.EADDRESS_TFHE);
        return eaddress.wrap(Impl.verifyInput(input));
    }

    // ********** BATCH INPUT VERIFICATION ************* //
    // Each `asE*s` verifies a batch of inputs authenticated by a SINGLE
    // signature over keccak256(h_0 || ... || h_n), where each h_i is the same
    // per-input message hash used by the single-input `asE*` functions. Outputs
    // are returned in input order. Inputs are the `external*` ciphertext handles;
    // as with the single-input `external*` overloads, securityZone is 0.

    /// @notice Verifies a batch of externalEbool inputs sharing one signature.
    function asEbools(externalEbool[] memory values, bytes memory signature) internal returns (ebool[] memory result) {
        UnsignedEncryptedInput[] memory inputs = new UnsignedEncryptedInput[](values.length);
        for (uint256 i = 0; i < values.length; i++) {
            inputs[i] = UnsignedEncryptedInput(uint256(externalEbool.unwrap(values[i])), 0, Utils.EBOOL_TFHE);
        }
        bytes32[] memory hashes = Impl.verifyBatchInputs(inputs, signature);
        // bytes32[] and ebool[] have identical memory layout, so reinterpret in place instead of copying.
        assembly ("memory-safe") {
            result := hashes
        }
    }

    /// @notice Verifies a batch of ABI-encoded (uint256 ctHash, uint8 securityZone, uint8 utype) ebool inputs sharing one signature.
    function asEbools(bytes[] memory values, bytes memory signature) internal returns (ebool[] memory result) {
        UnsignedEncryptedInput[] memory inputs = Utils.batchInputsFromBytes(values, Utils.EBOOL_TFHE);
        bytes32[] memory hashes = Impl.verifyBatchInputs(inputs, signature);
        // bytes32[] and ebool[] have identical memory layout, so reinterpret in place instead of copying.
        assembly ("memory-safe") {
            result := hashes
        }
    }

    /// @notice Verifies a batch of externalEuint8 inputs sharing one signature.
    function asEuint8s(externalEuint8[] memory values, bytes memory signature) internal returns (euint8[] memory result) {
        UnsignedEncryptedInput[] memory inputs = new UnsignedEncryptedInput[](values.length);
        for (uint256 i = 0; i < values.length; i++) {
            inputs[i] = UnsignedEncryptedInput(uint256(externalEuint8.unwrap(values[i])), 0, Utils.EUINT8_TFHE);
        }
        bytes32[] memory hashes = Impl.verifyBatchInputs(inputs, signature);
        // bytes32[] and euint8[] have identical memory layout, so reinterpret in place instead of copying.
        assembly ("memory-safe") {
            result := hashes
        }
    }

    /// @notice Verifies a batch of ABI-encoded (uint256 ctHash, uint8 securityZone, uint8 utype) euint8 inputs sharing one signature.
    function asEuint8s(bytes[] memory values, bytes memory signature) internal returns (euint8[] memory result) {
        UnsignedEncryptedInput[] memory inputs = Utils.batchInputsFromBytes(values, Utils.EUINT8_TFHE);
        bytes32[] memory hashes = Impl.verifyBatchInputs(inputs, signature);
        // bytes32[] and euint8[] have identical memory layout, so reinterpret in place instead of copying.
        assembly ("memory-safe") {
            result := hashes
        }
    }

    /// @notice Verifies a batch of externalEuint16 inputs sharing one signature.
    function asEuint16s(externalEuint16[] memory values, bytes memory signature) internal returns (euint16[] memory result) {
        UnsignedEncryptedInput[] memory inputs = new UnsignedEncryptedInput[](values.length);
        for (uint256 i = 0; i < values.length; i++) {
            inputs[i] = UnsignedEncryptedInput(uint256(externalEuint16.unwrap(values[i])), 0, Utils.EUINT16_TFHE);
        }
        bytes32[] memory hashes = Impl.verifyBatchInputs(inputs, signature);
        // bytes32[] and euint16[] have identical memory layout, so reinterpret in place instead of copying.
        assembly ("memory-safe") {
            result := hashes
        }
    }

    /// @notice Verifies a batch of ABI-encoded (uint256 ctHash, uint8 securityZone, uint8 utype) euint16 inputs sharing one signature.
    function asEuint16s(bytes[] memory values, bytes memory signature) internal returns (euint16[] memory result) {
        UnsignedEncryptedInput[] memory inputs = Utils.batchInputsFromBytes(values, Utils.EUINT16_TFHE);
        bytes32[] memory hashes = Impl.verifyBatchInputs(inputs, signature);
        // bytes32[] and euint16[] have identical memory layout, so reinterpret in place instead of copying.
        assembly ("memory-safe") {
            result := hashes
        }
    }

    /// @notice Verifies a batch of externalEuint32 inputs sharing one signature.
    function asEuint32s(externalEuint32[] memory values, bytes memory signature) internal returns (euint32[] memory result) {
        UnsignedEncryptedInput[] memory inputs = new UnsignedEncryptedInput[](values.length);
        for (uint256 i = 0; i < values.length; i++) {
            inputs[i] = UnsignedEncryptedInput(uint256(externalEuint32.unwrap(values[i])), 0, Utils.EUINT32_TFHE);
        }
        bytes32[] memory hashes = Impl.verifyBatchInputs(inputs, signature);
        // bytes32[] and euint32[] have identical memory layout, so reinterpret in place instead of copying.
        assembly ("memory-safe") {
            result := hashes
        }
    }

    /// @notice Verifies a batch of ABI-encoded (uint256 ctHash, uint8 securityZone, uint8 utype) euint32 inputs sharing one signature.
    function asEuint32s(bytes[] memory values, bytes memory signature) internal returns (euint32[] memory result) {
        UnsignedEncryptedInput[] memory inputs = Utils.batchInputsFromBytes(values, Utils.EUINT32_TFHE);
        bytes32[] memory hashes = Impl.verifyBatchInputs(inputs, signature);
        // bytes32[] and euint32[] have identical memory layout, so reinterpret in place instead of copying.
        assembly ("memory-safe") {
            result := hashes
        }
    }

    /// @notice Verifies a batch of externalEuint64 inputs sharing one signature.
    function asEuint64s(externalEuint64[] memory values, bytes memory signature) internal returns (euint64[] memory result) {
        UnsignedEncryptedInput[] memory inputs = new UnsignedEncryptedInput[](values.length);
        for (uint256 i = 0; i < values.length; i++) {
            inputs[i] = UnsignedEncryptedInput(uint256(externalEuint64.unwrap(values[i])), 0, Utils.EUINT64_TFHE);
        }
        bytes32[] memory hashes = Impl.verifyBatchInputs(inputs, signature);
        // bytes32[] and euint64[] have identical memory layout, so reinterpret in place instead of copying.
        assembly ("memory-safe") {
            result := hashes
        }
    }

    /// @notice Verifies a batch of ABI-encoded (uint256 ctHash, uint8 securityZone, uint8 utype) euint64 inputs sharing one signature.
    function asEuint64s(bytes[] memory values, bytes memory signature) internal returns (euint64[] memory result) {
        UnsignedEncryptedInput[] memory inputs = Utils.batchInputsFromBytes(values, Utils.EUINT64_TFHE);
        bytes32[] memory hashes = Impl.verifyBatchInputs(inputs, signature);
        // bytes32[] and euint64[] have identical memory layout, so reinterpret in place instead of copying.
        assembly ("memory-safe") {
            result := hashes
        }
    }

    /// @notice Verifies a batch of externalEuint128 inputs sharing one signature.
    function asEuint128s(externalEuint128[] memory values, bytes memory signature) internal returns (euint128[] memory result) {
        UnsignedEncryptedInput[] memory inputs = new UnsignedEncryptedInput[](values.length);
        for (uint256 i = 0; i < values.length; i++) {
            inputs[i] = UnsignedEncryptedInput(uint256(externalEuint128.unwrap(values[i])), 0, Utils.EUINT128_TFHE);
        }
        bytes32[] memory hashes = Impl.verifyBatchInputs(inputs, signature);
        // bytes32[] and euint128[] have identical memory layout, so reinterpret in place instead of copying.
        assembly ("memory-safe") {
            result := hashes
        }
    }

    /// @notice Verifies a batch of ABI-encoded (uint256 ctHash, uint8 securityZone, uint8 utype) euint128 inputs sharing one signature.
    function asEuint128s(bytes[] memory values, bytes memory signature) internal returns (euint128[] memory result) {
        UnsignedEncryptedInput[] memory inputs = Utils.batchInputsFromBytes(values, Utils.EUINT128_TFHE);
        bytes32[] memory hashes = Impl.verifyBatchInputs(inputs, signature);
        // bytes32[] and euint128[] have identical memory layout, so reinterpret in place instead of copying.
        assembly ("memory-safe") {
            result := hashes
        }
    }

    /// @notice Verifies a batch of externalEaddress inputs sharing one signature.
    function asEaddresses(externalEaddress[] memory values, bytes memory signature) internal returns (eaddress[] memory result) {
        UnsignedEncryptedInput[] memory inputs = new UnsignedEncryptedInput[](values.length);
        for (uint256 i = 0; i < values.length; i++) {
            inputs[i] = UnsignedEncryptedInput(uint256(externalEaddress.unwrap(values[i])), 0, Utils.EADDRESS_TFHE);
        }
        bytes32[] memory hashes = Impl.verifyBatchInputs(inputs, signature);
        // bytes32[] and eaddress[] have identical memory layout, so reinterpret in place instead of copying.
        assembly ("memory-safe") {
            result := hashes
        }
    }

    /// @notice Verifies a batch of ABI-encoded (uint256 ctHash, uint8 securityZone, uint8 utype) eaddress inputs sharing one signature.
    function asEaddresses(bytes[] memory values, bytes memory signature) internal returns (eaddress[] memory result) {
        UnsignedEncryptedInput[] memory inputs = Utils.batchInputsFromBytes(values, Utils.EADDRESS_TFHE);
        bytes32[] memory hashes = Impl.verifyBatchInputs(inputs, signature);
        // bytes32[] and eaddress[] have identical memory layout, so reinterpret in place instead of copying.
        assembly ("memory-safe") {
            result := hashes
        }
    }

    // ********** TYPE CASTING ************* //
    /// @notice Converts a ebool to an euint8
    function asEuint8(ebool value) internal returns (euint8) {
        return euint8.wrap(Impl.cast(ebool.unwrap(value), Utils.EUINT8_TFHE));
    }
    /// @notice Converts a ebool to an euint16
    function asEuint16(ebool value) internal returns (euint16) {
        return euint16.wrap(Impl.cast(ebool.unwrap(value), Utils.EUINT16_TFHE));
    }
    /// @notice Converts a ebool to an euint32
    function asEuint32(ebool value) internal returns (euint32) {
        return euint32.wrap(Impl.cast(ebool.unwrap(value), Utils.EUINT32_TFHE));
    }
    /// @notice Converts a ebool to an euint64
    function asEuint64(ebool value) internal returns (euint64) {
        return euint64.wrap(Impl.cast(ebool.unwrap(value), Utils.EUINT64_TFHE));
    }
    /// @notice Converts a ebool to an euint128
    function asEuint128(ebool value) internal returns (euint128) {
        return euint128.wrap(Impl.cast(ebool.unwrap(value), Utils.EUINT128_TFHE));
    }

    /// @notice Converts a euint8 to an ebool
    function asEbool(euint8 value) internal returns (ebool) {
        return ne(value, asEuint8(0));
    }
    /// @notice Converts a euint8 to an euint16
    function asEuint16(euint8 value) internal returns (euint16) {
        return euint16.wrap(Impl.cast(euint8.unwrap(value), Utils.EUINT16_TFHE));
    }
    /// @notice Converts a euint8 to an euint32
    function asEuint32(euint8 value) internal returns (euint32) {
        return euint32.wrap(Impl.cast(euint8.unwrap(value), Utils.EUINT32_TFHE));
    }
    /// @notice Converts a euint8 to an euint64
    function asEuint64(euint8 value) internal returns (euint64) {
        return euint64.wrap(Impl.cast(euint8.unwrap(value), Utils.EUINT64_TFHE));
    }
    /// @notice Converts a euint8 to an euint128
    function asEuint128(euint8 value) internal returns (euint128) {
        return euint128.wrap(Impl.cast(euint8.unwrap(value), Utils.EUINT128_TFHE));
    }

    /// @notice Converts a euint16 to an ebool
    function asEbool(euint16 value) internal returns (ebool) {
        return ne(value, asEuint16(0));
    }
    /// @notice Converts a euint16 to an euint8
    function asEuint8(euint16 value) internal returns (euint8) {
        return euint8.wrap(Impl.cast(euint16.unwrap(value), Utils.EUINT8_TFHE));
    }
    /// @notice Converts a euint16 to an euint32
    function asEuint32(euint16 value) internal returns (euint32) {
        return euint32.wrap(Impl.cast(euint16.unwrap(value), Utils.EUINT32_TFHE));
    }
    /// @notice Converts a euint16 to an euint64
    function asEuint64(euint16 value) internal returns (euint64) {
        return euint64.wrap(Impl.cast(euint16.unwrap(value), Utils.EUINT64_TFHE));
    }
    /// @notice Converts a euint16 to an euint128
    function asEuint128(euint16 value) internal returns (euint128) {
        return euint128.wrap(Impl.cast(euint16.unwrap(value), Utils.EUINT128_TFHE));
    }

    /// @notice Converts a euint32 to an ebool
    function asEbool(euint32 value) internal returns (ebool) {
        return ne(value, asEuint32(0));
    }
    /// @notice Converts a euint32 to an euint8
    function asEuint8(euint32 value) internal returns (euint8) {
        return euint8.wrap(Impl.cast(euint32.unwrap(value), Utils.EUINT8_TFHE));
    }
    /// @notice Converts a euint32 to an euint16
    function asEuint16(euint32 value) internal returns (euint16) {
        return euint16.wrap(Impl.cast(euint32.unwrap(value), Utils.EUINT16_TFHE));
    }
    /// @notice Converts a euint32 to an euint64
    function asEuint64(euint32 value) internal returns (euint64) {
        return euint64.wrap(Impl.cast(euint32.unwrap(value), Utils.EUINT64_TFHE));
    }
    /// @notice Converts a euint32 to an euint128
    function asEuint128(euint32 value) internal returns (euint128) {
        return euint128.wrap(Impl.cast(euint32.unwrap(value), Utils.EUINT128_TFHE));
    }

    /// @notice Converts a euint64 to an ebool
    function asEbool(euint64 value) internal returns (ebool) {
        return ne(value, asEuint64(0));
    }
    /// @notice Converts a euint64 to an euint8
    function asEuint8(euint64 value) internal returns (euint8) {
        return euint8.wrap(Impl.cast(euint64.unwrap(value), Utils.EUINT8_TFHE));
    }
    /// @notice Converts a euint64 to an euint16
    function asEuint16(euint64 value) internal returns (euint16) {
        return euint16.wrap(Impl.cast(euint64.unwrap(value), Utils.EUINT16_TFHE));
    }
    /// @notice Converts a euint64 to an euint32
    function asEuint32(euint64 value) internal returns (euint32) {
        return euint32.wrap(Impl.cast(euint64.unwrap(value), Utils.EUINT32_TFHE));
    }
    /// @notice Converts a euint64 to an euint128
    function asEuint128(euint64 value) internal returns (euint128) {
        return euint128.wrap(Impl.cast(euint64.unwrap(value), Utils.EUINT128_TFHE));
    }

    /// @notice Converts a euint128 to an ebool
    function asEbool(euint128 value) internal returns (ebool) {
        return ne(value, asEuint128(0));
    }
    /// @notice Converts a euint128 to an euint8
    function asEuint8(euint128 value) internal returns (euint8) {
        return euint8.wrap(Impl.cast(euint128.unwrap(value), Utils.EUINT8_TFHE));
    }
    /// @notice Converts a euint128 to an euint16
    function asEuint16(euint128 value) internal returns (euint16) {
        return euint16.wrap(Impl.cast(euint128.unwrap(value), Utils.EUINT16_TFHE));
    }
    /// @notice Converts a euint128 to an euint32
    function asEuint32(euint128 value) internal returns (euint32) {
        return euint32.wrap(Impl.cast(euint128.unwrap(value), Utils.EUINT32_TFHE));
    }
    /// @notice Converts a euint128 to an euint64
    function asEuint64(euint128 value) internal returns (euint64) {
        return euint64.wrap(Impl.cast(euint128.unwrap(value), Utils.EUINT64_TFHE));
    }

    /// @notice Converts a eaddress to an ebool
    function asEbool(eaddress value) internal returns (ebool) {
        return ne(value, asEaddress(address(0)));
    }
    /// @notice Converts a eaddress to an euint8
    function asEuint8(eaddress value) internal returns (euint8) {
        return euint8.wrap(Impl.cast(eaddress.unwrap(value), Utils.EUINT8_TFHE));
    }
    /// @notice Converts a eaddress to an euint16
    function asEuint16(eaddress value) internal returns (euint16) {
        return euint16.wrap(Impl.cast(eaddress.unwrap(value), Utils.EUINT16_TFHE));
    }
    /// @notice Converts a eaddress to an euint32
    function asEuint32(eaddress value) internal returns (euint32) {
        return euint32.wrap(Impl.cast(eaddress.unwrap(value), Utils.EUINT32_TFHE));
    }
    /// @notice Converts a eaddress to an euint64
    function asEuint64(eaddress value) internal returns (euint64) {
        return euint64.wrap(Impl.cast(eaddress.unwrap(value), Utils.EUINT64_TFHE));
    }
    /// @notice Converts a eaddress to an euint128
    function asEuint128(eaddress value) internal returns (euint128) {
        return euint128.wrap(Impl.cast(eaddress.unwrap(value), Utils.EUINT128_TFHE));
    }
    /// @notice Converts a plaintext boolean value to a ciphertext ebool
    /// @dev Privacy: The input value is public, therefore the resulting ciphertext should be considered public until involved in an fhe operation
    /// @return A ciphertext representation of the input
    function asEbool(bool value) internal returns (ebool) {
        return asEbool(value, 0);
    }
    /// @notice Converts a plaintext boolean value to a ciphertext ebool, specifying security zone
    /// @dev Privacy: The input value is public, therefore the resulting ciphertext should be considered public until involved in an fhe operation
    /// @return A ciphertext representation of the input
    function asEbool(bool value, int32 securityZone) internal returns (ebool) {
        uint256 sVal = 0;
        if (value) {
            sVal = 1;
        }
        bytes32 ct = Impl.trivialEncrypt(sVal, Utils.EBOOL_TFHE, securityZone);
        return ebool.wrap(ct);
    }
    /// @notice Converts a uint256 to an euint8
    /// @dev Privacy: The input value is public, therefore the resulting ciphertext should be considered public until involved in an fhe operation
    function asEuint8(uint256 value) internal returns (euint8) {
        return asEuint8(value, 0);
    }
    /// @notice Converts a uint256 to an euint8, specifying security zone
    /// @dev Privacy: The input value is public, therefore the resulting ciphertext should be considered public until involved in an fhe operation
    function asEuint8(uint256 value, int32 securityZone) internal returns (euint8) {
        bytes32 ct = Impl.trivialEncrypt(value, Utils.EUINT8_TFHE, securityZone);
        return euint8.wrap(ct);
    }
    /// @notice Converts a uint256 to an euint16
    /// @dev Privacy: The input value is public, therefore the resulting ciphertext should be considered public until involved in an fhe operation
    function asEuint16(uint256 value) internal returns (euint16) {
        return asEuint16(value, 0);
    }
    /// @notice Converts a uint256 to an euint16, specifying security zone
    /// @dev Privacy: The input value is public, therefore the resulting ciphertext should be considered public until involved in an fhe operation
    function asEuint16(uint256 value, int32 securityZone) internal returns (euint16) {
        bytes32 ct = Impl.trivialEncrypt(value, Utils.EUINT16_TFHE, securityZone);
        return euint16.wrap(ct);
    }
    /// @notice Converts a uint256 to an euint32
    /// @dev Privacy: The input value is public, therefore the resulting ciphertext should be considered public until involved in an fhe operation
    function asEuint32(uint256 value) internal returns (euint32) {
        return asEuint32(value, 0);
    }
    /// @notice Converts a uint256 to an euint32, specifying security zone
    /// @dev Privacy: The input value is public, therefore the resulting ciphertext should be considered public until involved in an fhe operation
    function asEuint32(uint256 value, int32 securityZone) internal returns (euint32) {
        bytes32 ct = Impl.trivialEncrypt(value, Utils.EUINT32_TFHE, securityZone);
        return euint32.wrap(ct);
    }
    /// @notice Converts a uint256 to an euint64
    /// @dev Privacy: The input value is public, therefore the resulting ciphertext should be considered public until involved in an fhe operation
    function asEuint64(uint256 value) internal returns (euint64) {
        return asEuint64(value, 0);
    }
    /// @notice Converts a uint256 to an euint64, specifying security zone
    /// @dev Privacy: The input value is public, therefore the resulting ciphertext should be considered public until involved in an fhe operation
    function asEuint64(uint256 value, int32 securityZone) internal returns (euint64) {
        bytes32 ct = Impl.trivialEncrypt(value, Utils.EUINT64_TFHE, securityZone);
        return euint64.wrap(ct);
    }
    /// @notice Converts a uint256 to an euint128
    /// @dev Privacy: The input value is public, therefore the resulting ciphertext should be considered public until involved in an fhe operation
    function asEuint128(uint256 value) internal returns (euint128) {
        return asEuint128(value, 0);
    }
    /// @notice Converts a uint256 to an euint128, specifying security zone
    /// @dev Privacy: The input value is public, therefore the resulting ciphertext should be considered public until involved in an fhe operation
    function asEuint128(uint256 value, int32 securityZone) internal returns (euint128) {
        bytes32 ct = Impl.trivialEncrypt(value, Utils.EUINT128_TFHE, securityZone);
        return euint128.wrap(ct);
    }
    /// @notice Converts a address to an eaddress
    /// @dev Privacy: The input value is public, therefore the resulting ciphertext should be considered public until involved in an fhe operation
    /// Allows for a better user experience when working with eaddresses
    function asEaddress(address value) internal returns (eaddress) {
        return asEaddress(value, 0);
    }
    /// @notice Converts a address to an eaddress, specifying security zone
    /// @dev Privacy: The input value is public, therefore the resulting ciphertext should be considered public until involved in an fhe operation
    /// Allows for a better user experience when working with eaddresses
    function asEaddress(address value, int32 securityZone) internal returns (eaddress) {
        bytes32 ct = Impl.trivialEncrypt(uint256(uint160(value)), Utils.EADDRESS_TFHE, securityZone);
        return eaddress.wrap(ct);
    }

    /// @notice Grants permission to an account to operate on the encrypted boolean value
    /// @dev Allows the specified account to access the ciphertext
    /// @param ctHash The encrypted boolean value to grant access to
    /// @param account The address being granted permission
    function allow(ebool ctHash, address account) internal {
        Common.tm().allow(uint256(ebool.unwrap(ctHash)), account);
    }

    /// @notice Grants permission to an account to operate on the encrypted 8-bit unsigned integer
    /// @dev Allows the specified account to access the ciphertext
    /// @param ctHash The encrypted uint8 value to grant access to
    /// @param account The address being granted permission
    function allow(euint8 ctHash, address account) internal {
        Common.tm().allow(uint256(euint8.unwrap(ctHash)), account);
    }

    /// @notice Grants permission to an account to operate on the encrypted 16-bit unsigned integer
    /// @dev Allows the specified account to access the ciphertext
    /// @param ctHash The encrypted uint16 value to grant access to
    /// @param account The address being granted permission
    function allow(euint16 ctHash, address account) internal {
        Common.tm().allow(uint256(euint16.unwrap(ctHash)), account);
    }

    /// @notice Grants permission to an account to operate on the encrypted 32-bit unsigned integer
    /// @dev Allows the specified account to access the ciphertext
    /// @param ctHash The encrypted uint32 value to grant access to
    /// @param account The address being granted permission
    function allow(euint32 ctHash, address account) internal {
        Common.tm().allow(uint256(euint32.unwrap(ctHash)), account);
    }

    /// @notice Grants permission to an account to operate on the encrypted 64-bit unsigned integer
    /// @dev Allows the specified account to access the ciphertext
    /// @param ctHash The encrypted uint64 value to grant access to
    /// @param account The address being granted permission
    function allow(euint64 ctHash, address account) internal {
        Common.tm().allow(uint256(euint64.unwrap(ctHash)), account);
    }

    /// @notice Grants permission to an account to operate on the encrypted 128-bit unsigned integer
    /// @dev Allows the specified account to access the ciphertext
    /// @param ctHash The encrypted uint128 value to grant access to
    /// @param account The address being granted permission
    function allow(euint128 ctHash, address account) internal {
        Common.tm().allow(uint256(euint128.unwrap(ctHash)), account);
    }

    /// @notice Grants permission to an account to operate on the encrypted address
    /// @dev Allows the specified account to access the ciphertext
    /// @param ctHash The encrypted address value to grant access to
    /// @param account The address being granted permission
    function allow(eaddress ctHash, address account) internal {
        Common.tm().allow(uint256(eaddress.unwrap(ctHash)), account);
    }

    /// @notice Grants global permission to operate on the encrypted boolean value
    /// @dev Allows all accounts to access the ciphertext
    /// @param ctHash The encrypted boolean value to grant global access to
    function allowGlobal(ebool ctHash) internal {
        Common.tm().allowGlobal(uint256(ebool.unwrap(ctHash)));
    }

    /// @notice Grants global permission to operate on the encrypted 8-bit unsigned integer
    /// @dev Allows all accounts to access the ciphertext
    /// @param ctHash The encrypted uint8 value to grant global access to
    function allowGlobal(euint8 ctHash) internal {
        Common.tm().allowGlobal(uint256(euint8.unwrap(ctHash)));
    }

    /// @notice Grants global permission to operate on the encrypted 16-bit unsigned integer
    /// @dev Allows all accounts to access the ciphertext
    /// @param ctHash The encrypted uint16 value to grant global access to
    function allowGlobal(euint16 ctHash) internal {
        Common.tm().allowGlobal(uint256(euint16.unwrap(ctHash)));
    }

    /// @notice Grants global permission to operate on the encrypted 32-bit unsigned integer
    /// @dev Allows all accounts to access the ciphertext
    /// @param ctHash The encrypted uint32 value to grant global access to
    function allowGlobal(euint32 ctHash) internal {
        Common.tm().allowGlobal(uint256(euint32.unwrap(ctHash)));
    }

    /// @notice Grants global permission to operate on the encrypted 64-bit unsigned integer
    /// @dev Allows all accounts to access the ciphertext
    /// @param ctHash The encrypted uint64 value to grant global access to
    function allowGlobal(euint64 ctHash) internal {
        Common.tm().allowGlobal(uint256(euint64.unwrap(ctHash)));
    }

    /// @notice Grants global permission to operate on the encrypted 128-bit unsigned integer
    /// @dev Allows all accounts to access the ciphertext
    /// @param ctHash The encrypted uint128 value to grant global access to
    function allowGlobal(euint128 ctHash) internal {
        Common.tm().allowGlobal(uint256(euint128.unwrap(ctHash)));
    }

    /// @notice Grants global permission to operate on the encrypted address
    /// @dev Allows all accounts to access the ciphertext
    /// @param ctHash The encrypted address value to grant global access to
    function allowGlobal(eaddress ctHash) internal {
        Common.tm().allowGlobal(uint256(eaddress.unwrap(ctHash)));
    }

    /// @notice Grants public permission to operate on the encrypted boolean value
    /// @dev Allows all accounts to access the ciphertext
    /// @param ctHash The encrypted boolean value to grant public access to
    function allowPublic(ebool ctHash) internal {
        Common.tm().allowGlobal(uint256(ebool.unwrap(ctHash)));
    }

    /// @notice Grants public permission to operate on the encrypted 8-bit unsigned integer
    /// @dev Allows all accounts to access the ciphertext
    /// @param ctHash The encrypted uint8 value to grant public access to
    function allowPublic(euint8 ctHash) internal {
        Common.tm().allowGlobal(uint256(euint8.unwrap(ctHash)));
    }

    /// @notice Grants public permission to operate on the encrypted 16-bit unsigned integer
    /// @dev Allows all accounts to access the ciphertext
    /// @param ctHash The encrypted uint16 value to grant public access to
    function allowPublic(euint16 ctHash) internal {
        Common.tm().allowGlobal(uint256(euint16.unwrap(ctHash)));
    }

    /// @notice Grants public permission to operate on the encrypted 32-bit unsigned integer
    /// @dev Allows all accounts to access the ciphertext
    /// @param ctHash The encrypted uint32 value to grant public access to
    function allowPublic(euint32 ctHash) internal {
        Common.tm().allowGlobal(uint256(euint32.unwrap(ctHash)));
    }

    /// @notice Grants public permission to operate on the encrypted 64-bit unsigned integer
    /// @dev Allows all accounts to access the ciphertext
    /// @param ctHash The encrypted uint64 value to grant public access to
    function allowPublic(euint64 ctHash) internal {
        Common.tm().allowGlobal(uint256(euint64.unwrap(ctHash)));
    }

    /// @notice Grants public permission to operate on the encrypted 128-bit unsigned integer
    /// @dev Allows all accounts to access the ciphertext
    /// @param ctHash The encrypted uint128 value to grant public access to
    function allowPublic(euint128 ctHash) internal {
        Common.tm().allowGlobal(uint256(euint128.unwrap(ctHash)));
    }

    /// @notice Grants public permission to operate on the encrypted address
    /// @dev Allows all accounts to access the ciphertext
    /// @param ctHash The encrypted address value to grant public access to
    function allowPublic(eaddress ctHash) internal {
        Common.tm().allowGlobal(uint256(eaddress.unwrap(ctHash)));
    }

    /// @notice Checks if an account has permission to operate on the encrypted boolean value
    /// @dev Returns whether the specified account can access the ciphertext
    /// @param ctHash The encrypted boolean value to check access for
    /// @param account The address to check permissions for
    /// @return True if the account has permission, false otherwise
    function isAllowed(ebool ctHash, address account) internal view returns (bool) {
        return Common.tm().isAllowed(uint256(ebool.unwrap(ctHash)), account);
    }

    /// @notice Checks if an account has permission to operate on the encrypted 8-bit unsigned integer
    /// @dev Returns whether the specified account can access the ciphertext
    /// @param ctHash The encrypted uint8 value to check access for
    /// @param account The address to check permissions for
    /// @return True if the account has permission, false otherwise
    function isAllowed(euint8 ctHash, address account) internal view returns (bool) {
        return Common.tm().isAllowed(uint256(euint8.unwrap(ctHash)), account);
    }

    /// @notice Checks if an account has permission to operate on the encrypted 16-bit unsigned integer
    /// @dev Returns whether the specified account can access the ciphertext
    /// @param ctHash The encrypted uint16 value to check access for
    /// @param account The address to check permissions for
    /// @return True if the account has permission, false otherwise
    function isAllowed(euint16 ctHash, address account) internal view returns (bool) {
        return Common.tm().isAllowed(uint256(euint16.unwrap(ctHash)), account);
    }

    /// @notice Checks if an account has permission to operate on the encrypted 32-bit unsigned integer
    /// @dev Returns whether the specified account can access the ciphertext
    /// @param ctHash The encrypted uint32 value to check access for
    /// @param account The address to check permissions for
    /// @return True if the account has permission, false otherwise
    function isAllowed(euint32 ctHash, address account) internal view returns (bool) {
        return Common.tm().isAllowed(uint256(euint32.unwrap(ctHash)), account);
    }

    /// @notice Checks if an account has permission to operate on the encrypted 64-bit unsigned integer
    /// @dev Returns whether the specified account can access the ciphertext
    /// @param ctHash The encrypted uint64 value to check access for
    /// @param account The address to check permissions for
    /// @return True if the account has permission, false otherwise
    function isAllowed(euint64 ctHash, address account) internal view returns (bool) {
        return Common.tm().isAllowed(uint256(euint64.unwrap(ctHash)), account);
    }

    /// @notice Checks if an account has permission to operate on the encrypted 128-bit unsigned integer
    /// @dev Returns whether the specified account can access the ciphertext
    /// @param ctHash The encrypted uint128 value to check access for
    /// @param account The address to check permissions for
    /// @return True if the account has permission, false otherwise
    function isAllowed(euint128 ctHash, address account) internal view returns (bool) {
        return Common.tm().isAllowed(uint256(euint128.unwrap(ctHash)), account);
    }


    /// @notice Checks if an account has permission to operate on the encrypted address
    /// @dev Returns whether the specified account can access the ciphertext
    /// @param ctHash The encrypted address value to check access for
    /// @param account The address to check permissions for
    /// @return True if the account has permission, false otherwise
    function isAllowed(eaddress ctHash, address account) internal view returns (bool) {
        return Common.tm().isAllowed(uint256(eaddress.unwrap(ctHash)), account);
    }

    /// @notice Checks if an encrypted boolean value is publicly (globally) allowed
    /// @param ctHash The encrypted boolean value to check
    /// @return True if the ciphertext is publicly allowed, false otherwise
    function isPubliclyAllowed(ebool ctHash) internal view returns (bool) {
        return Common.tm().isPubliclyAllowed(uint256(ebool.unwrap(ctHash)));
    }

    /// @notice Checks if an encrypted 8-bit unsigned integer is publicly (globally) allowed
    /// @param ctHash The encrypted uint8 value to check
    /// @return True if the ciphertext is publicly allowed, false otherwise
    function isPubliclyAllowed(euint8 ctHash) internal view returns (bool) {
        return Common.tm().isPubliclyAllowed(uint256(euint8.unwrap(ctHash)));
    }

    /// @notice Checks if an encrypted 16-bit unsigned integer is publicly (globally) allowed
    /// @param ctHash The encrypted uint16 value to check
    /// @return True if the ciphertext is publicly allowed, false otherwise
    function isPubliclyAllowed(euint16 ctHash) internal view returns (bool) {
        return Common.tm().isPubliclyAllowed(uint256(euint16.unwrap(ctHash)));
    }

    /// @notice Checks if an encrypted 32-bit unsigned integer is publicly (globally) allowed
    /// @param ctHash The encrypted uint32 value to check
    /// @return True if the ciphertext is publicly allowed, false otherwise
    function isPubliclyAllowed(euint32 ctHash) internal view returns (bool) {
        return Common.tm().isPubliclyAllowed(uint256(euint32.unwrap(ctHash)));
    }

    /// @notice Checks if an encrypted 64-bit unsigned integer is publicly (globally) allowed
    /// @param ctHash The encrypted uint64 value to check
    /// @return True if the ciphertext is publicly allowed, false otherwise
    function isPubliclyAllowed(euint64 ctHash) internal view returns (bool) {
        return Common.tm().isPubliclyAllowed(uint256(euint64.unwrap(ctHash)));
    }

    /// @notice Checks if an encrypted 128-bit unsigned integer is publicly (globally) allowed
    /// @param ctHash The encrypted uint128 value to check
    /// @return True if the ciphertext is publicly allowed, false otherwise
    function isPubliclyAllowed(euint128 ctHash) internal view returns (bool) {
        return Common.tm().isPubliclyAllowed(uint256(euint128.unwrap(ctHash)));
    }

    /// @notice Checks if an encrypted address is publicly (globally) allowed
    /// @param ctHash The encrypted address value to check
    /// @return True if the ciphertext is publicly allowed, false otherwise
    function isPubliclyAllowed(eaddress ctHash) internal view returns (bool) {
        return Common.tm().isPubliclyAllowed(uint256(eaddress.unwrap(ctHash)));
    }

    /// @notice Grants permission to the current contract to operate on the encrypted boolean value
    /// @dev Allows this contract to access the ciphertext
    /// @param ctHash The encrypted boolean value to grant access to
    function allowThis(ebool ctHash) internal {
        Common.tm().allow(uint256(ebool.unwrap(ctHash)), address(this));
    }

    /// @notice Grants permission to the current contract to operate on the encrypted 8-bit unsigned integer
    /// @dev Allows this contract to access the ciphertext
    /// @param ctHash The encrypted uint8 value to grant access to
    function allowThis(euint8 ctHash) internal {
        Common.tm().allow(uint256(euint8.unwrap(ctHash)), address(this));
    }

    /// @notice Grants permission to the current contract to operate on the encrypted 16-bit unsigned integer
    /// @dev Allows this contract to access the ciphertext
    /// @param ctHash The encrypted uint16 value to grant access to
    function allowThis(euint16 ctHash) internal {
        Common.tm().allow(uint256(euint16.unwrap(ctHash)), address(this));
    }

    /// @notice Grants permission to the current contract to operate on the encrypted 32-bit unsigned integer
    /// @dev Allows this contract to access the ciphertext
    /// @param ctHash The encrypted uint32 value to grant access to
    function allowThis(euint32 ctHash) internal {
        Common.tm().allow(uint256(euint32.unwrap(ctHash)), address(this));
    }

    /// @notice Grants permission to the current contract to operate on the encrypted 64-bit unsigned integer
    /// @dev Allows this contract to access the ciphertext
    /// @param ctHash The encrypted uint64 value to grant access to
    function allowThis(euint64 ctHash) internal {
        Common.tm().allow(uint256(euint64.unwrap(ctHash)), address(this));
    }

    /// @notice Grants permission to the current contract to operate on the encrypted 128-bit unsigned integer
    /// @dev Allows this contract to access the ciphertext
    /// @param ctHash The encrypted uint128 value to grant access to
    function allowThis(euint128 ctHash) internal {
        Common.tm().allow(uint256(euint128.unwrap(ctHash)), address(this));
    }

    /// @notice Grants permission to the current contract to operate on the encrypted address
    /// @dev Allows this contract to access the ciphertext
    /// @param ctHash The encrypted address value to grant access to
    function allowThis(eaddress ctHash) internal {
        Common.tm().allow(uint256(eaddress.unwrap(ctHash)), address(this));
    }

    /// @notice Grants permission to the message sender to operate on the encrypted boolean value
    /// @dev Allows the transaction sender to access the ciphertext
    /// @param ctHash The encrypted boolean value to grant access to
    function allowSender(ebool ctHash) internal {
        Common.tm().allow(uint256(ebool.unwrap(ctHash)), msg.sender);
    }

    /// @notice Grants permission to the message sender to operate on the encrypted 8-bit unsigned integer
    /// @dev Allows the transaction sender to access the ciphertext
    /// @param ctHash The encrypted uint8 value to grant access to
    function allowSender(euint8 ctHash) internal {
        Common.tm().allow(uint256(euint8.unwrap(ctHash)), msg.sender);
    }

    /// @notice Grants permission to the message sender to operate on the encrypted 16-bit unsigned integer
    /// @dev Allows the transaction sender to access the ciphertext
    /// @param ctHash The encrypted uint16 value to grant access to
    function allowSender(euint16 ctHash) internal {
        Common.tm().allow(uint256(euint16.unwrap(ctHash)), msg.sender);
    }

    /// @notice Grants permission to the message sender to operate on the encrypted 32-bit unsigned integer
    /// @dev Allows the transaction sender to access the ciphertext
    /// @param ctHash The encrypted uint32 value to grant access to
    function allowSender(euint32 ctHash) internal {
        Common.tm().allow(uint256(euint32.unwrap(ctHash)), msg.sender);
    }

    /// @notice Grants permission to the message sender to operate on the encrypted 64-bit unsigned integer
    /// @dev Allows the transaction sender to access the ciphertext
    /// @param ctHash The encrypted uint64 value to grant access to
    function allowSender(euint64 ctHash) internal {
        Common.tm().allow(uint256(euint64.unwrap(ctHash)), msg.sender);
    }

    /// @notice Grants permission to the message sender to operate on the encrypted 128-bit unsigned integer
    /// @dev Allows the transaction sender to access the ciphertext
    /// @param ctHash The encrypted uint128 value to grant access to
    function allowSender(euint128 ctHash) internal {
        Common.tm().allow(uint256(euint128.unwrap(ctHash)), msg.sender);
    }

    /// @notice Grants permission to the message sender to operate on the encrypted address
    /// @dev Allows the transaction sender to access the ciphertext
    /// @param ctHash The encrypted address value to grant access to
    function allowSender(eaddress ctHash) internal {
        Common.tm().allow(uint256(eaddress.unwrap(ctHash)), msg.sender);
    }

    /// @notice Grants temporary permission to an account to operate on the encrypted boolean value
    /// @dev Allows the specified account to access the ciphertext for the current transaction only
    /// @param ctHash The encrypted boolean value to grant temporary access to
    /// @param account The address being granted temporary permission
    function allowTransient(ebool ctHash, address account) internal {
        Common.tm().allowTransient(uint256(ebool.unwrap(ctHash)), account);
    }

    /// @notice Grants temporary permission to an account to operate on the encrypted 8-bit unsigned integer
    /// @dev Allows the specified account to access the ciphertext for the current transaction only
    /// @param ctHash The encrypted uint8 value to grant temporary access to
    /// @param account The address being granted temporary permission
    function allowTransient(euint8 ctHash, address account) internal {
        Common.tm().allowTransient(uint256(euint8.unwrap(ctHash)), account);
    }

    /// @notice Grants temporary permission to an account to operate on the encrypted 16-bit unsigned integer
    /// @dev Allows the specified account to access the ciphertext for the current transaction only
    /// @param ctHash The encrypted uint16 value to grant temporary access to
    /// @param account The address being granted temporary permission
    function allowTransient(euint16 ctHash, address account) internal {
        Common.tm().allowTransient(uint256(euint16.unwrap(ctHash)), account);
    }

    /// @notice Grants temporary permission to an account to operate on the encrypted 32-bit unsigned integer
    /// @dev Allows the specified account to access the ciphertext for the current transaction only
    /// @param ctHash The encrypted uint32 value to grant temporary access to
    /// @param account The address being granted temporary permission
    function allowTransient(euint32 ctHash, address account) internal {
        Common.tm().allowTransient(uint256(euint32.unwrap(ctHash)), account);
    }

    /// @notice Grants temporary permission to an account to operate on the encrypted 64-bit unsigned integer
    /// @dev Allows the specified account to access the ciphertext for the current transaction only
    /// @param ctHash The encrypted uint64 value to grant temporary access to
    /// @param account The address being granted temporary permission
    function allowTransient(euint64 ctHash, address account) internal {
        Common.tm().allowTransient(uint256(euint64.unwrap(ctHash)), account);
    }

    /// @notice Grants temporary permission to an account to operate on the encrypted 128-bit unsigned integer
    /// @dev Allows the specified account to access the ciphertext for the current transaction only
    /// @param ctHash The encrypted uint128 value to grant temporary access to
    /// @param account The address being granted temporary permission
    function allowTransient(euint128 ctHash, address account) internal {
        Common.tm().allowTransient(uint256(euint128.unwrap(ctHash)), account);
    }

    /// @notice Grants temporary permission to an account to operate on the encrypted address
    /// @dev Allows the specified account to access the ciphertext for the current transaction only
    /// @param ctHash The encrypted address value to grant temporary access to
    /// @param account The address being granted temporary permission
    function allowTransient(eaddress ctHash, address account) internal {
        Common.tm().allowTransient(uint256(eaddress.unwrap(ctHash)), account);
    }

    // ********** SHARE / RECEIVE ************* //

    /// @notice Grants `receiver` transient access to the ciphertext and directs it at `receiver`
    ///         for the duration of this transaction.
    /// @dev Reverts with SenderNotAllowed unless this contract is itself allowed on `ctHash`.
    /// @param ctHash The value to share
    /// @param receiver The contract the value is being handed to
    /// @return A sharedEbool carrying the handle and the permission to use it
    function shareEbool(ebool ctHash, address receiver) internal returns (sharedEbool) {
        Common.tm().shareCtHash(uint256(ebool.unwrap(ctHash)), receiver);
        return sharedEbool.wrap(ebool.unwrap(ctHash));
    }

    /// @notice Consumes a share that arrived as an argument to the enclosing function.
    /// @dev This is an internal function, so it is inlined into the receiving contract and
    ///      `msg.sender` is that contract's caller — the sharer is resolved automatically.
    ///      Reverts with NotShared if no share is pending, or UnexpectedSharer if the pending
    ///      share came from a party other than the caller.
    /// @param shared The value received as a parameter
    /// @return The usable handle, with transient access for the rest of this transaction
    function receiveEboolParam(sharedEbool shared) internal returns (ebool) {
        bytes32 handle = sharedEbool.unwrap(shared);
        Common.tm().receiveCtHash(uint256(handle), msg.sender);
        return ebool.wrap(handle);
    }

    /// @notice Consumes a share that arrived as the return value of a call this contract made.
    /// @param shared The value returned by the call
    /// @param callee MUST be the address called in the same expression. Passing any other
    ///        address checks who created the share rather than who handed it over.
    /// @return The usable handle, with transient access for the rest of this transaction
    function receiveEboolFromCall(sharedEbool shared, address callee) internal returns (ebool) {
        bytes32 handle = sharedEbool.unwrap(shared);
        Common.tm().receiveCtHash(uint256(handle), callee);
        return ebool.wrap(handle);
    }

    /// @notice Grants `receiver` transient access to the ciphertext and directs it at `receiver`
    ///         for the duration of this transaction.
    /// @dev Reverts with SenderNotAllowed unless this contract is itself allowed on `ctHash`.
    /// @param ctHash The value to share
    /// @param receiver The contract the value is being handed to
    /// @return A sharedEuint8 carrying the handle and the permission to use it
    function shareEuint8(euint8 ctHash, address receiver) internal returns (sharedEuint8) {
        Common.tm().shareCtHash(uint256(euint8.unwrap(ctHash)), receiver);
        return sharedEuint8.wrap(euint8.unwrap(ctHash));
    }

    /// @notice Consumes a share that arrived as an argument to the enclosing function.
    /// @dev This is an internal function, so it is inlined into the receiving contract and
    ///      `msg.sender` is that contract's caller — the sharer is resolved automatically.
    ///      Reverts with NotShared if no share is pending, or UnexpectedSharer if the pending
    ///      share came from a party other than the caller.
    /// @param shared The value received as a parameter
    /// @return The usable handle, with transient access for the rest of this transaction
    function receiveEuint8Param(sharedEuint8 shared) internal returns (euint8) {
        bytes32 handle = sharedEuint8.unwrap(shared);
        Common.tm().receiveCtHash(uint256(handle), msg.sender);
        return euint8.wrap(handle);
    }

    /// @notice Consumes a share that arrived as the return value of a call this contract made.
    /// @param shared The value returned by the call
    /// @param callee MUST be the address called in the same expression. Passing any other
    ///        address checks who created the share rather than who handed it over.
    /// @return The usable handle, with transient access for the rest of this transaction
    function receiveEuint8FromCall(sharedEuint8 shared, address callee) internal returns (euint8) {
        bytes32 handle = sharedEuint8.unwrap(shared);
        Common.tm().receiveCtHash(uint256(handle), callee);
        return euint8.wrap(handle);
    }

    /// @notice Grants `receiver` transient access to the ciphertext and directs it at `receiver`
    ///         for the duration of this transaction.
    /// @dev Reverts with SenderNotAllowed unless this contract is itself allowed on `ctHash`.
    /// @param ctHash The value to share
    /// @param receiver The contract the value is being handed to
    /// @return A sharedEuint16 carrying the handle and the permission to use it
    function shareEuint16(euint16 ctHash, address receiver) internal returns (sharedEuint16) {
        Common.tm().shareCtHash(uint256(euint16.unwrap(ctHash)), receiver);
        return sharedEuint16.wrap(euint16.unwrap(ctHash));
    }

    /// @notice Consumes a share that arrived as an argument to the enclosing function.
    /// @dev This is an internal function, so it is inlined into the receiving contract and
    ///      `msg.sender` is that contract's caller — the sharer is resolved automatically.
    ///      Reverts with NotShared if no share is pending, or UnexpectedSharer if the pending
    ///      share came from a party other than the caller.
    /// @param shared The value received as a parameter
    /// @return The usable handle, with transient access for the rest of this transaction
    function receiveEuint16Param(sharedEuint16 shared) internal returns (euint16) {
        bytes32 handle = sharedEuint16.unwrap(shared);
        Common.tm().receiveCtHash(uint256(handle), msg.sender);
        return euint16.wrap(handle);
    }

    /// @notice Consumes a share that arrived as the return value of a call this contract made.
    /// @param shared The value returned by the call
    /// @param callee MUST be the address called in the same expression. Passing any other
    ///        address checks who created the share rather than who handed it over.
    /// @return The usable handle, with transient access for the rest of this transaction
    function receiveEuint16FromCall(sharedEuint16 shared, address callee) internal returns (euint16) {
        bytes32 handle = sharedEuint16.unwrap(shared);
        Common.tm().receiveCtHash(uint256(handle), callee);
        return euint16.wrap(handle);
    }

    /// @notice Grants `receiver` transient access to the ciphertext and directs it at `receiver`
    ///         for the duration of this transaction.
    /// @dev Reverts with SenderNotAllowed unless this contract is itself allowed on `ctHash`.
    /// @param ctHash The value to share
    /// @param receiver The contract the value is being handed to
    /// @return A sharedEuint32 carrying the handle and the permission to use it
    function shareEuint32(euint32 ctHash, address receiver) internal returns (sharedEuint32) {
        Common.tm().shareCtHash(uint256(euint32.unwrap(ctHash)), receiver);
        return sharedEuint32.wrap(euint32.unwrap(ctHash));
    }

    /// @notice Consumes a share that arrived as an argument to the enclosing function.
    /// @dev This is an internal function, so it is inlined into the receiving contract and
    ///      `msg.sender` is that contract's caller — the sharer is resolved automatically.
    ///      Reverts with NotShared if no share is pending, or UnexpectedSharer if the pending
    ///      share came from a party other than the caller.
    /// @param shared The value received as a parameter
    /// @return The usable handle, with transient access for the rest of this transaction
    function receiveEuint32Param(sharedEuint32 shared) internal returns (euint32) {
        bytes32 handle = sharedEuint32.unwrap(shared);
        Common.tm().receiveCtHash(uint256(handle), msg.sender);
        return euint32.wrap(handle);
    }

    /// @notice Consumes a share that arrived as the return value of a call this contract made.
    /// @param shared The value returned by the call
    /// @param callee MUST be the address called in the same expression. Passing any other
    ///        address checks who created the share rather than who handed it over.
    /// @return The usable handle, with transient access for the rest of this transaction
    function receiveEuint32FromCall(sharedEuint32 shared, address callee) internal returns (euint32) {
        bytes32 handle = sharedEuint32.unwrap(shared);
        Common.tm().receiveCtHash(uint256(handle), callee);
        return euint32.wrap(handle);
    }

    /// @notice Grants `receiver` transient access to the ciphertext and directs it at `receiver`
    ///         for the duration of this transaction.
    /// @dev Reverts with SenderNotAllowed unless this contract is itself allowed on `ctHash`.
    /// @param ctHash The value to share
    /// @param receiver The contract the value is being handed to
    /// @return A sharedEuint64 carrying the handle and the permission to use it
    function shareEuint64(euint64 ctHash, address receiver) internal returns (sharedEuint64) {
        Common.tm().shareCtHash(uint256(euint64.unwrap(ctHash)), receiver);
        return sharedEuint64.wrap(euint64.unwrap(ctHash));
    }

    /// @notice Consumes a share that arrived as an argument to the enclosing function.
    /// @dev This is an internal function, so it is inlined into the receiving contract and
    ///      `msg.sender` is that contract's caller — the sharer is resolved automatically.
    ///      Reverts with NotShared if no share is pending, or UnexpectedSharer if the pending
    ///      share came from a party other than the caller.
    /// @param shared The value received as a parameter
    /// @return The usable handle, with transient access for the rest of this transaction
    function receiveEuint64Param(sharedEuint64 shared) internal returns (euint64) {
        bytes32 handle = sharedEuint64.unwrap(shared);
        Common.tm().receiveCtHash(uint256(handle), msg.sender);
        return euint64.wrap(handle);
    }

    /// @notice Consumes a share that arrived as the return value of a call this contract made.
    /// @param shared The value returned by the call
    /// @param callee MUST be the address called in the same expression. Passing any other
    ///        address checks who created the share rather than who handed it over.
    /// @return The usable handle, with transient access for the rest of this transaction
    function receiveEuint64FromCall(sharedEuint64 shared, address callee) internal returns (euint64) {
        bytes32 handle = sharedEuint64.unwrap(shared);
        Common.tm().receiveCtHash(uint256(handle), callee);
        return euint64.wrap(handle);
    }

    /// @notice Grants `receiver` transient access to the ciphertext and directs it at `receiver`
    ///         for the duration of this transaction.
    /// @dev Reverts with SenderNotAllowed unless this contract is itself allowed on `ctHash`.
    /// @param ctHash The value to share
    /// @param receiver The contract the value is being handed to
    /// @return A sharedEuint128 carrying the handle and the permission to use it
    function shareEuint128(euint128 ctHash, address receiver) internal returns (sharedEuint128) {
        Common.tm().shareCtHash(uint256(euint128.unwrap(ctHash)), receiver);
        return sharedEuint128.wrap(euint128.unwrap(ctHash));
    }

    /// @notice Consumes a share that arrived as an argument to the enclosing function.
    /// @dev This is an internal function, so it is inlined into the receiving contract and
    ///      `msg.sender` is that contract's caller — the sharer is resolved automatically.
    ///      Reverts with NotShared if no share is pending, or UnexpectedSharer if the pending
    ///      share came from a party other than the caller.
    /// @param shared The value received as a parameter
    /// @return The usable handle, with transient access for the rest of this transaction
    function receiveEuint128Param(sharedEuint128 shared) internal returns (euint128) {
        bytes32 handle = sharedEuint128.unwrap(shared);
        Common.tm().receiveCtHash(uint256(handle), msg.sender);
        return euint128.wrap(handle);
    }

    /// @notice Consumes a share that arrived as the return value of a call this contract made.
    /// @param shared The value returned by the call
    /// @param callee MUST be the address called in the same expression. Passing any other
    ///        address checks who created the share rather than who handed it over.
    /// @return The usable handle, with transient access for the rest of this transaction
    function receiveEuint128FromCall(sharedEuint128 shared, address callee) internal returns (euint128) {
        bytes32 handle = sharedEuint128.unwrap(shared);
        Common.tm().receiveCtHash(uint256(handle), callee);
        return euint128.wrap(handle);
    }

    /// @notice Grants `receiver` transient access to the ciphertext and directs it at `receiver`
    ///         for the duration of this transaction.
    /// @dev Reverts with SenderNotAllowed unless this contract is itself allowed on `ctHash`.
    /// @param ctHash The value to share
    /// @param receiver The contract the value is being handed to
    /// @return A sharedEaddress carrying the handle and the permission to use it
    function shareEaddress(eaddress ctHash, address receiver) internal returns (sharedEaddress) {
        Common.tm().shareCtHash(uint256(eaddress.unwrap(ctHash)), receiver);
        return sharedEaddress.wrap(eaddress.unwrap(ctHash));
    }

    /// @notice Consumes a share that arrived as an argument to the enclosing function.
    /// @dev This is an internal function, so it is inlined into the receiving contract and
    ///      `msg.sender` is that contract's caller — the sharer is resolved automatically.
    ///      Reverts with NotShared if no share is pending, or UnexpectedSharer if the pending
    ///      share came from a party other than the caller.
    /// @param shared The value received as a parameter
    /// @return The usable handle, with transient access for the rest of this transaction
    function receiveEaddressParam(sharedEaddress shared) internal returns (eaddress) {
        bytes32 handle = sharedEaddress.unwrap(shared);
        Common.tm().receiveCtHash(uint256(handle), msg.sender);
        return eaddress.wrap(handle);
    }

    /// @notice Consumes a share that arrived as the return value of a call this contract made.
    /// @param shared The value returned by the call
    /// @param callee MUST be the address called in the same expression. Passing any other
    ///        address checks who created the share rather than who handed it over.
    /// @return The usable handle, with transient access for the rest of this transaction
    function receiveEaddressFromCall(sharedEaddress shared, address callee) internal returns (eaddress) {
        bytes32 handle = sharedEaddress.unwrap(shared);
        Common.tm().receiveCtHash(uint256(handle), callee);
        return eaddress.wrap(handle);
    }


    // ********** PUBLISH DECRYPT RESULT ************* //

    /// @notice Publish a signed decrypt result to the chain
    /// @dev Anyone with a valid signature from the decrypt network can call this
    /// @param ctHash The ciphertext hash
    /// @param result The decrypted plaintext value
    /// @param signature The ECDSA signature from the decrypt network
    function publishDecryptResult(uint256 ctHash, uint256 result, bytes memory signature) internal {
        Impl.publishDecryptResult(bytes32(ctHash), result, signature);
    }

    /// @notice Publish a signed decrypt result for an ebool
    function publishDecryptResult(ebool input, bool result, bytes memory signature) internal {
        Impl.publishDecryptResult(ebool.unwrap(input), result ? 1 : 0, signature);
    }

    /// @notice Publish a signed decrypt result for an euint8
    function publishDecryptResult(euint8 input, uint8 result, bytes memory signature) internal {
        Impl.publishDecryptResult(euint8.unwrap(input), uint256(result), signature);
    }

    /// @notice Publish a signed decrypt result for an euint16
    function publishDecryptResult(euint16 input, uint16 result, bytes memory signature) internal {
        Impl.publishDecryptResult(euint16.unwrap(input), uint256(result), signature);
    }

    /// @notice Publish a signed decrypt result for an euint32
    function publishDecryptResult(euint32 input, uint32 result, bytes memory signature) internal {
        Impl.publishDecryptResult(euint32.unwrap(input), uint256(result), signature);
    }

    /// @notice Publish a signed decrypt result for an euint64
    function publishDecryptResult(euint64 input, uint64 result, bytes memory signature) internal {
        Impl.publishDecryptResult(euint64.unwrap(input), uint256(result), signature);
    }

    /// @notice Publish a signed decrypt result for an euint128
    function publishDecryptResult(euint128 input, uint128 result, bytes memory signature) internal {
        Impl.publishDecryptResult(euint128.unwrap(input), uint256(result), signature);
    }

    /// @notice Publish a signed decrypt result for an eaddress
    function publishDecryptResult(eaddress input, address result, bytes memory signature) internal {
        Impl.publishDecryptResult(eaddress.unwrap(input), uint256(uint160(result)), signature);
    }

    /// @notice Publish multiple ebool decrypt results in one transaction
    function publishDecryptResultBatch(ebool[] memory inputs, bool[] memory results, bytes[] memory signatures) internal {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(ebool.unwrap(inputs[i]));
            resultsUint[i] = results[i] ? 1 : 0;
        }
        Impl.publishDecryptResultBatch(ctHashes, resultsUint, signatures);
    }

    /// @notice Publish multiple euint8 decrypt results in one transaction
    function publishDecryptResultBatch(euint8[] memory inputs, uint8[] memory results, bytes[] memory signatures) internal {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(euint8.unwrap(inputs[i]));
            resultsUint[i] = uint256(results[i]);
        }
        Impl.publishDecryptResultBatch(ctHashes, resultsUint, signatures);
    }

    /// @notice Publish multiple euint16 decrypt results in one transaction
    function publishDecryptResultBatch(euint16[] memory inputs, uint16[] memory results, bytes[] memory signatures) internal {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(euint16.unwrap(inputs[i]));
            resultsUint[i] = uint256(results[i]);
        }
        Impl.publishDecryptResultBatch(ctHashes, resultsUint, signatures);
    }

    /// @notice Publish multiple euint32 decrypt results in one transaction
    function publishDecryptResultBatch(euint32[] memory inputs, uint32[] memory results, bytes[] memory signatures) internal {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(euint32.unwrap(inputs[i]));
            resultsUint[i] = uint256(results[i]);
        }
        Impl.publishDecryptResultBatch(ctHashes, resultsUint, signatures);
    }

    /// @notice Publish multiple euint64 decrypt results in one transaction
    function publishDecryptResultBatch(euint64[] memory inputs, uint64[] memory results, bytes[] memory signatures) internal {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(euint64.unwrap(inputs[i]));
            resultsUint[i] = uint256(results[i]);
        }
        Impl.publishDecryptResultBatch(ctHashes, resultsUint, signatures);
    }

    /// @notice Publish multiple euint128 decrypt results in one transaction
    function publishDecryptResultBatch(euint128[] memory inputs, uint128[] memory results, bytes[] memory signatures) internal {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(euint128.unwrap(inputs[i]));
            resultsUint[i] = uint256(results[i]);
        }
        Impl.publishDecryptResultBatch(ctHashes, resultsUint, signatures);
    }

    /// @notice Publish multiple eaddress decrypt results in one transaction
    function publishDecryptResultBatch(eaddress[] memory inputs, address[] memory results, bytes[] memory signatures) internal {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(eaddress.unwrap(inputs[i]));
            resultsUint[i] = uint256(uint160(results[i]));
        }
        Impl.publishDecryptResultBatch(ctHashes, resultsUint, signatures);
    }

    // ********** VERIFY DECRYPT RESULT ************* //

    /// @notice Verify a decrypt result signature without publishing
    /// @param ctHash The ciphertext hash
    /// @param result The decrypted plaintext value
    /// @param signature The ECDSA signature from the decrypt network
    /// @return True if signature is valid
    function verifyDecryptResult(uint256 ctHash, uint256 result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResult(bytes32(ctHash), result, signature);
    }

    /// @notice Verify a decrypt result signature for an ebool
    function verifyDecryptResult(ebool input, bool result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResult(ebool.unwrap(input), result ? 1 : 0, signature);
    }

    /// @notice Verify a decrypt result signature for an euint8
    function verifyDecryptResult(euint8 input, uint8 result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResult(euint8.unwrap(input), uint256(result), signature);
    }

    /// @notice Verify a decrypt result signature for an euint16
    function verifyDecryptResult(euint16 input, uint16 result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResult(euint16.unwrap(input), uint256(result), signature);
    }

    /// @notice Verify a decrypt result signature for an euint32
    function verifyDecryptResult(euint32 input, uint32 result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResult(euint32.unwrap(input), uint256(result), signature);
    }

    /// @notice Verify a decrypt result signature for an euint64
    function verifyDecryptResult(euint64 input, uint64 result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResult(euint64.unwrap(input), uint256(result), signature);
    }

    /// @notice Verify a decrypt result signature for an euint128
    function verifyDecryptResult(euint128 input, uint128 result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResult(euint128.unwrap(input), uint256(result), signature);
    }

    /// @notice Verify a decrypt result signature for an eaddress
    function verifyDecryptResult(eaddress input, address result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResult(eaddress.unwrap(input), uint256(uint160(result)), signature);
    }

    // ********** VERIFY DECRYPT RESULT BATCH ************* //

    /// @notice Verify multiple ebool decrypt result signatures
    function verifyDecryptResultBatch(ebool[] memory inputs, bool[] memory results, bytes[] memory signatures) internal view returns (bool) {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(ebool.unwrap(inputs[i]));
            resultsUint[i] = results[i] ? 1 : 0;
        }
        return Impl.verifyDecryptResultBatch(ctHashes, resultsUint, signatures);
    }

    /// @notice Verify multiple euint8 decrypt result signatures
    function verifyDecryptResultBatch(euint8[] memory inputs, uint8[] memory results, bytes[] memory signatures) internal view returns (bool) {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(euint8.unwrap(inputs[i]));
            resultsUint[i] = uint256(results[i]);
        }
        return Impl.verifyDecryptResultBatch(ctHashes, resultsUint, signatures);
    }

    /// @notice Verify multiple euint16 decrypt result signatures
    function verifyDecryptResultBatch(euint16[] memory inputs, uint16[] memory results, bytes[] memory signatures) internal view returns (bool) {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(euint16.unwrap(inputs[i]));
            resultsUint[i] = uint256(results[i]);
        }
        return Impl.verifyDecryptResultBatch(ctHashes, resultsUint, signatures);
    }

    /// @notice Verify multiple euint32 decrypt result signatures
    function verifyDecryptResultBatch(euint32[] memory inputs, uint32[] memory results, bytes[] memory signatures) internal view returns (bool) {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(euint32.unwrap(inputs[i]));
            resultsUint[i] = uint256(results[i]);
        }
        return Impl.verifyDecryptResultBatch(ctHashes, resultsUint, signatures);
    }

    /// @notice Verify multiple euint64 decrypt result signatures
    function verifyDecryptResultBatch(euint64[] memory inputs, uint64[] memory results, bytes[] memory signatures) internal view returns (bool) {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(euint64.unwrap(inputs[i]));
            resultsUint[i] = uint256(results[i]);
        }
        return Impl.verifyDecryptResultBatch(ctHashes, resultsUint, signatures);
    }

    /// @notice Verify multiple euint128 decrypt result signatures
    function verifyDecryptResultBatch(euint128[] memory inputs, uint128[] memory results, bytes[] memory signatures) internal view returns (bool) {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(euint128.unwrap(inputs[i]));
            resultsUint[i] = uint256(results[i]);
        }
        return Impl.verifyDecryptResultBatch(ctHashes, resultsUint, signatures);
    }

    /// @notice Verify multiple eaddress decrypt result signatures
    function verifyDecryptResultBatch(eaddress[] memory inputs, address[] memory results, bytes[] memory signatures) internal view returns (bool) {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(eaddress.unwrap(inputs[i]));
            resultsUint[i] = uint256(uint160(results[i]));
        }
        return Impl.verifyDecryptResultBatch(ctHashes, resultsUint, signatures);
    }

    // ********** VERIFY DECRYPT RESULT SAFE ************* //

    /// @notice Verify a decrypt result signature without publishing (non-reverting)
    /// @param ctHash The ciphertext hash
    /// @param result The decrypted plaintext value
    /// @param signature The ECDSA signature from the decrypt network
    /// @return True if signature is valid, false otherwise
    function verifyDecryptResultSafe(uint256 ctHash, uint256 result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResultSafe(bytes32(ctHash), result, signature);
    }

    /// @notice Verify a decrypt result signature for an ebool (non-reverting)
    function verifyDecryptResultSafe(ebool input, bool result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResultSafe(ebool.unwrap(input), result ? 1 : 0, signature);
    }

    /// @notice Verify a decrypt result signature for an euint8 (non-reverting)
    function verifyDecryptResultSafe(euint8 input, uint8 result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResultSafe(euint8.unwrap(input), uint256(result), signature);
    }

    /// @notice Verify a decrypt result signature for an euint16 (non-reverting)
    function verifyDecryptResultSafe(euint16 input, uint16 result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResultSafe(euint16.unwrap(input), uint256(result), signature);
    }

    /// @notice Verify a decrypt result signature for an euint32 (non-reverting)
    function verifyDecryptResultSafe(euint32 input, uint32 result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResultSafe(euint32.unwrap(input), uint256(result), signature);
    }

    /// @notice Verify a decrypt result signature for an euint64 (non-reverting)
    function verifyDecryptResultSafe(euint64 input, uint64 result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResultSafe(euint64.unwrap(input), uint256(result), signature);
    }

    /// @notice Verify a decrypt result signature for an euint128 (non-reverting)
    function verifyDecryptResultSafe(euint128 input, uint128 result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResultSafe(euint128.unwrap(input), uint256(result), signature);
    }

    /// @notice Verify a decrypt result signature for an eaddress (non-reverting)
    function verifyDecryptResultSafe(eaddress input, address result, bytes memory signature) internal view returns (bool) {
        return Impl.verifyDecryptResultSafe(eaddress.unwrap(input), uint256(uint160(result)), signature);
    }

    // ********** VERIFY DECRYPT RESULT BATCH SAFE ************* //

    /// @notice Verify multiple ebool decrypt result signatures (non-reverting)
    function verifyDecryptResultBatchSafe(ebool[] memory inputs, bool[] memory results, bytes[] memory signatures) internal view returns (bool[] memory) {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(ebool.unwrap(inputs[i]));
            resultsUint[i] = results[i] ? 1 : 0;
        }
        return Impl.verifyDecryptResultBatchSafe(ctHashes, resultsUint, signatures);
    }

    /// @notice Verify multiple euint8 decrypt result signatures (non-reverting)
    function verifyDecryptResultBatchSafe(euint8[] memory inputs, uint8[] memory results, bytes[] memory signatures) internal view returns (bool[] memory) {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(euint8.unwrap(inputs[i]));
            resultsUint[i] = uint256(results[i]);
        }
        return Impl.verifyDecryptResultBatchSafe(ctHashes, resultsUint, signatures);
    }

    /// @notice Verify multiple euint16 decrypt result signatures (non-reverting)
    function verifyDecryptResultBatchSafe(euint16[] memory inputs, uint16[] memory results, bytes[] memory signatures) internal view returns (bool[] memory) {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(euint16.unwrap(inputs[i]));
            resultsUint[i] = uint256(results[i]);
        }
        return Impl.verifyDecryptResultBatchSafe(ctHashes, resultsUint, signatures);
    }

    /// @notice Verify multiple euint32 decrypt result signatures (non-reverting)
    function verifyDecryptResultBatchSafe(euint32[] memory inputs, uint32[] memory results, bytes[] memory signatures) internal view returns (bool[] memory) {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(euint32.unwrap(inputs[i]));
            resultsUint[i] = uint256(results[i]);
        }
        return Impl.verifyDecryptResultBatchSafe(ctHashes, resultsUint, signatures);
    }

    /// @notice Verify multiple euint64 decrypt result signatures (non-reverting)
    function verifyDecryptResultBatchSafe(euint64[] memory inputs, uint64[] memory results, bytes[] memory signatures) internal view returns (bool[] memory) {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(euint64.unwrap(inputs[i]));
            resultsUint[i] = uint256(results[i]);
        }
        return Impl.verifyDecryptResultBatchSafe(ctHashes, resultsUint, signatures);
    }

    /// @notice Verify multiple euint128 decrypt result signatures (non-reverting)
    function verifyDecryptResultBatchSafe(euint128[] memory inputs, uint128[] memory results, bytes[] memory signatures) internal view returns (bool[] memory) {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(euint128.unwrap(inputs[i]));
            resultsUint[i] = uint256(results[i]);
        }
        return Impl.verifyDecryptResultBatchSafe(ctHashes, resultsUint, signatures);
    }

    /// @notice Verify multiple eaddress decrypt result signatures (non-reverting)
    function verifyDecryptResultBatchSafe(eaddress[] memory inputs, address[] memory results, bytes[] memory signatures) internal view returns (bool[] memory) {
        uint256[] memory ctHashes = new uint256[](inputs.length);
        uint256[] memory resultsUint = new uint256[](results.length);
        for (uint256 i = 0; i < inputs.length; i++) {
            ctHashes[i] = uint256(eaddress.unwrap(inputs[i]));
            resultsUint[i] = uint256(uint160(results[i]));
        }
        return Impl.verifyDecryptResultBatchSafe(ctHashes, resultsUint, signatures);
    }

    /// @notice Returns true if the encrypted boolean is initialized and false otherwise
    /// @param value the encrypted boolean value to check
    /// @return true if initialized, false otherwise
    function isInitialized(ebool value) internal pure returns (bool) {
        return Common.isInitialized(value);
    }

    /// @notice Returns true if the encrypted uint8 is initialized and false otherwise
    /// @param value the encrypted uint8 value to check
    /// @return true if initialized, false otherwise
    function isInitialized(euint8 value) internal pure returns (bool) {
        return Common.isInitialized(value);
    }

    /// @notice Returns true if the encrypted uint16 is initialized and false otherwise
    /// @param value the encrypted uint16 value to check
    /// @return true if initialized, false otherwise
    function isInitialized(euint16 value) internal pure returns (bool) {
        return Common.isInitialized(value);
    }

    /// @notice Returns true if the encrypted uint32 is initialized and false otherwise
    /// @param value the encrypted uint32 value to check
    /// @return true if initialized, false otherwise
    function isInitialized(euint32 value) internal pure returns (bool) {
        return Common.isInitialized(value);
    }

    /// @notice Returns true if the encrypted uint64 is initialized and false otherwise
    /// @param value the encrypted uint64 value to check
    /// @return true if initialized, false otherwise
    function isInitialized(euint64 value) internal pure returns (bool) {
        return Common.isInitialized(value);
    }

    /// @notice Returns true if the encrypted uint128 is initialized and false otherwise
    /// @param value the encrypted uint128 value to check
    /// @return true if initialized, false otherwise
    function isInitialized(euint128 value) internal pure returns (bool) {
        return Common.isInitialized(value);
    }

    /// @notice Returns true if the encrypted address is initialized and false otherwise
    /// @param value the encrypted address value to check
    /// @return true if initialized, false otherwise
    function isInitialized(eaddress value) internal pure returns (bool) {
        return Common.isInitialized(value);
    }

    /// @notice Unwraps an encrypted boolean value to its underlying bytes32 handle
    /// @param value the encrypted boolean value to unwrap
    /// @return the underlying bytes32 handle
    function unwrap(ebool value) internal pure returns (bytes32) {
        return ebool.unwrap(value);
    }

    /// @notice Unwraps an encrypted uint8 value to its underlying bytes32 handle
    /// @param value the encrypted uint8 value to unwrap
    /// @return the underlying bytes32 handle
    function unwrap(euint8 value) internal pure returns (bytes32) {
        return euint8.unwrap(value);
    }

    /// @notice Unwraps an encrypted uint16 value to its underlying bytes32 handle
    /// @param value the encrypted uint16 value to unwrap
    /// @return the underlying bytes32 handle
    function unwrap(euint16 value) internal pure returns (bytes32) {
        return euint16.unwrap(value);
    }

    /// @notice Unwraps an encrypted uint32 value to its underlying bytes32 handle
    /// @param value the encrypted uint32 value to unwrap
    /// @return the underlying bytes32 handle
    function unwrap(euint32 value) internal pure returns (bytes32) {
        return euint32.unwrap(value);
    }

    /// @notice Unwraps an encrypted uint64 value to its underlying bytes32 handle
    /// @param value the encrypted uint64 value to unwrap
    /// @return the underlying bytes32 handle
    function unwrap(euint64 value) internal pure returns (bytes32) {
        return euint64.unwrap(value);
    }

    /// @notice Unwraps an encrypted uint128 value to its underlying bytes32 handle
    /// @param value the encrypted uint128 value to unwrap
    /// @return the underlying bytes32 handle
    function unwrap(euint128 value) internal pure returns (bytes32) {
        return euint128.unwrap(value);
    }

    /// @notice Unwraps an encrypted address value to its underlying bytes32 handle
    /// @param value the encrypted address value to unwrap
    /// @return the underlying bytes32 handle
    function unwrap(eaddress value) internal pure returns (bytes32) {
        return eaddress.unwrap(value);
    }

    /// @notice Wraps a bytes32 handle into an encrypted boolean type
    /// @param handle the bytes32 ciphertext handle to wrap
    /// @return an ebool representing the encrypted value
    function wrapEbool(bytes32 handle) internal pure returns (ebool) {
        return ebool.wrap(handle);
    }

    /// @notice Wraps a bytes32 handle into an encrypted uint8 type
    /// @param handle the bytes32 ciphertext handle to wrap
    /// @return an euint8 representing the encrypted value
    function wrapEuint8(bytes32 handle) internal pure returns (euint8) {
        return euint8.wrap(handle);
    }

    /// @notice Wraps a bytes32 handle into an encrypted uint16 type
    /// @param handle the bytes32 ciphertext handle to wrap
    /// @return an euint16 representing the encrypted value
    function wrapEuint16(bytes32 handle) internal pure returns (euint16) {
        return euint16.wrap(handle);
    }

    /// @notice Wraps a bytes32 handle into an encrypted uint32 type
    /// @param handle the bytes32 ciphertext handle to wrap
    /// @return an euint32 representing the encrypted value
    function wrapEuint32(bytes32 handle) internal pure returns (euint32) {
        return euint32.wrap(handle);
    }

    /// @notice Wraps a bytes32 handle into an encrypted uint64 type
    /// @param handle the bytes32 ciphertext handle to wrap
    /// @return an euint64 representing the encrypted value
    function wrapEuint64(bytes32 handle) internal pure returns (euint64) {
        return euint64.wrap(handle);
    }

    /// @notice Wraps a bytes32 handle into an encrypted uint128 type
    /// @param handle the bytes32 ciphertext handle to wrap
    /// @return an euint128 representing the encrypted value
    function wrapEuint128(bytes32 handle) internal pure returns (euint128) {
        return euint128.wrap(handle);
    }

    /// @notice Wraps a bytes32 handle into an encrypted address type
    /// @param handle the bytes32 ciphertext handle to wrap
    /// @return an eaddress representing the encrypted value
    function wrapEaddress(bytes32 handle) internal pure returns (eaddress) {
        return eaddress.wrap(handle);
    }
}

// ********** BINDING DEFS ************* //

using BindingsEbool for ebool global;
library BindingsEbool {

    /// @notice Performs the eq operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type ebool
    /// @param rhs second input of type ebool
    /// @return the result of the eq
    function eq(ebool lhs, ebool rhs) internal returns (ebool) {
        return FHE.eq(lhs, rhs);
    }

    /// @notice Performs the ne operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type ebool
    /// @param rhs second input of type ebool
    /// @return the result of the ne
    function ne(ebool lhs, ebool rhs) internal returns (ebool) {
        return FHE.ne(lhs, rhs);
    }

    /// @notice Performs the not operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type ebool
    /// @return the result of the not
    function not(ebool lhs) internal returns (ebool) {
        return FHE.not(lhs);
    }

    /// @notice Performs the and operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type ebool
    /// @param rhs second input of type ebool
    /// @return the result of the and
    function and(ebool lhs, ebool rhs) internal returns (ebool) {
        return FHE.and(lhs, rhs);
    }

    /// @notice Performs the or operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type ebool
    /// @param rhs second input of type ebool
    /// @return the result of the or
    function or(ebool lhs, ebool rhs) internal returns (ebool) {
        return FHE.or(lhs, rhs);
    }

    /// @notice Performs the xor operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type ebool
    /// @param rhs second input of type ebool
    /// @return the result of the xor
    function xor(ebool lhs, ebool rhs) internal returns (ebool) {
        return FHE.xor(lhs, rhs);
    }
    function toU8(ebool value) internal returns (euint8) {
        return FHE.asEuint8(value);
    }
    function toU16(ebool value) internal returns (euint16) {
        return FHE.asEuint16(value);
    }
    function toU32(ebool value) internal returns (euint32) {
        return FHE.asEuint32(value);
    }
    function toU64(ebool value) internal returns (euint64) {
        return FHE.asEuint64(value);
    }
    function toU128(ebool value) internal returns (euint128) {
        return FHE.asEuint128(value);
    }
    function allow(ebool ctHash, address account) internal {
        FHE.allow(ctHash, account);
    }
    function isAllowed(ebool ctHash, address account) internal view returns (bool) {
        return FHE.isAllowed(ctHash, account);
    }
    function isPubliclyAllowed(ebool ctHash) internal view returns (bool) {
        return FHE.isPubliclyAllowed(ctHash);
    }
    function allowThis(ebool ctHash) internal {
        FHE.allowThis(ctHash);
    }
    function allowGlobal(ebool ctHash) internal {
        FHE.allowGlobal(ctHash);
    }
    function allowPublic(ebool ctHash) internal {
        FHE.allowPublic(ctHash);
    }
    function allowSender(ebool ctHash) internal {
        FHE.allowSender(ctHash);
    }
    function allowTransient(ebool ctHash, address account) internal {
        FHE.allowTransient(ctHash, account);
    }
    /// @notice Returns true if the encrypted boolean is initialized and false otherwise
    /// @param value the encrypted boolean value to check
    /// @return true if initialized, false otherwise
    function isInitialized(ebool value) internal pure returns (bool) {
        return FHE.isInitialized(value);
    }
    /// @notice Unwraps an encrypted boolean value to its underlying bytes32 handle
    /// @param value the encrypted boolean value to unwrap
    /// @return the underlying bytes32 handle
    function unwrap(ebool value) internal pure returns (bytes32) {
        return FHE.unwrap(value);
    }
}

using BindingsEuint8 for euint8 global;
library BindingsEuint8 {

    /// @notice Performs the add operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the add
    function add(euint8 lhs, euint8 rhs) internal returns (euint8) {
        return FHE.add(lhs, rhs);
    }

    /// @notice Performs the mul operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the mul
    function mul(euint8 lhs, euint8 rhs) internal returns (euint8) {
        return FHE.mul(lhs, rhs);
    }

    /// @notice Performs the div operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the div
    function div(euint8 lhs, euint8 rhs) internal returns (euint8) {
        return FHE.div(lhs, rhs);
    }

    /// @notice Performs the sub operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the sub
    function sub(euint8 lhs, euint8 rhs) internal returns (euint8) {
        return FHE.sub(lhs, rhs);
    }

    /// @notice Performs the eq operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the eq
    function eq(euint8 lhs, euint8 rhs) internal returns (ebool) {
        return FHE.eq(lhs, rhs);
    }

    /// @notice Performs the ne operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the ne
    function ne(euint8 lhs, euint8 rhs) internal returns (ebool) {
        return FHE.ne(lhs, rhs);
    }

    /// @notice Performs the not operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @return the result of the not
    function not(euint8 lhs) internal returns (euint8) {
        return FHE.not(lhs);
    }

    /// @notice Performs the and operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the and
    function and(euint8 lhs, euint8 rhs) internal returns (euint8) {
        return FHE.and(lhs, rhs);
    }

    /// @notice Performs the or operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the or
    function or(euint8 lhs, euint8 rhs) internal returns (euint8) {
        return FHE.or(lhs, rhs);
    }

    /// @notice Performs the xor operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the xor
    function xor(euint8 lhs, euint8 rhs) internal returns (euint8) {
        return FHE.xor(lhs, rhs);
    }

    /// @notice Performs the gt operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the gt
    function gt(euint8 lhs, euint8 rhs) internal returns (ebool) {
        return FHE.gt(lhs, rhs);
    }

    /// @notice Performs the gte operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the gte
    function gte(euint8 lhs, euint8 rhs) internal returns (ebool) {
        return FHE.gte(lhs, rhs);
    }

    /// @notice Performs the lt operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the lt
    function lt(euint8 lhs, euint8 rhs) internal returns (ebool) {
        return FHE.lt(lhs, rhs);
    }

    /// @notice Performs the lte operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the lte
    function lte(euint8 lhs, euint8 rhs) internal returns (ebool) {
        return FHE.lte(lhs, rhs);
    }

    /// @notice Performs the rem operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the rem
    function rem(euint8 lhs, euint8 rhs) internal returns (euint8) {
        return FHE.rem(lhs, rhs);
    }

    /// @notice Performs the max operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the max
    function max(euint8 lhs, euint8 rhs) internal returns (euint8) {
        return FHE.max(lhs, rhs);
    }

    /// @notice Performs the min operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the min
    function min(euint8 lhs, euint8 rhs) internal returns (euint8) {
        return FHE.min(lhs, rhs);
    }

    /// @notice Performs the shl operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the shl
    function shl(euint8 lhs, euint8 rhs) internal returns (euint8) {
        return FHE.shl(lhs, rhs);
    }

    /// @notice Performs the shr operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the shr
    function shr(euint8 lhs, euint8 rhs) internal returns (euint8) {
        return FHE.shr(lhs, rhs);
    }

    /// @notice Performs the rol operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the rol
    function rol(euint8 lhs, euint8 rhs) internal returns (euint8) {
        return FHE.rol(lhs, rhs);
    }

    /// @notice Performs the ror operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @param rhs second input of type euint8
    /// @return the result of the ror
    function ror(euint8 lhs, euint8 rhs) internal returns (euint8) {
        return FHE.ror(lhs, rhs);
    }

    /// @notice Performs the square operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint8
    /// @return the result of the square
    function square(euint8 lhs) internal returns (euint8) {
        return FHE.square(lhs);
    }
    function toBool(euint8 value) internal  returns (ebool) {
        return FHE.asEbool(value);
    }
    function toU16(euint8 value) internal returns (euint16) {
        return FHE.asEuint16(value);
    }
    function toU32(euint8 value) internal returns (euint32) {
        return FHE.asEuint32(value);
    }
    function toU64(euint8 value) internal returns (euint64) {
        return FHE.asEuint64(value);
    }
    function toU128(euint8 value) internal returns (euint128) {
        return FHE.asEuint128(value);
    }
    function allow(euint8 ctHash, address account) internal {
        FHE.allow(ctHash, account);
    }
    function isAllowed(euint8 ctHash, address account) internal view returns (bool) {
        return FHE.isAllowed(ctHash, account);
    }
    function isPubliclyAllowed(euint8 ctHash) internal view returns (bool) {
        return FHE.isPubliclyAllowed(ctHash);
    }
    function allowThis(euint8 ctHash) internal {
        FHE.allowThis(ctHash);
    }
    function allowGlobal(euint8 ctHash) internal {
        FHE.allowGlobal(ctHash);
    }
    function allowPublic(euint8 ctHash) internal {
        FHE.allowPublic(ctHash);
    }
    function allowSender(euint8 ctHash) internal {
        FHE.allowSender(ctHash);
    }
    function allowTransient(euint8 ctHash, address account) internal {
        FHE.allowTransient(ctHash, account);
    }
    /// @notice Returns true if the encrypted uint8 is initialized and false otherwise
    /// @param value the encrypted uint8 value to check
    /// @return true if initialized, false otherwise
    function isInitialized(euint8 value) internal pure returns (bool) {
        return FHE.isInitialized(value);
    }
    /// @notice Unwraps an encrypted uint8 value to its underlying bytes32 handle
    /// @param value the encrypted uint8 value to unwrap
    /// @return the underlying bytes32 handle
    function unwrap(euint8 value) internal pure returns (bytes32) {
        return FHE.unwrap(value);
    }
}

using BindingsEuint16 for euint16 global;
library BindingsEuint16 {

    /// @notice Performs the add operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the add
    function add(euint16 lhs, euint16 rhs) internal returns (euint16) {
        return FHE.add(lhs, rhs);
    }

    /// @notice Performs the mul operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the mul
    function mul(euint16 lhs, euint16 rhs) internal returns (euint16) {
        return FHE.mul(lhs, rhs);
    }

    /// @notice Performs the div operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the div
    function div(euint16 lhs, euint16 rhs) internal returns (euint16) {
        return FHE.div(lhs, rhs);
    }

    /// @notice Performs the sub operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the sub
    function sub(euint16 lhs, euint16 rhs) internal returns (euint16) {
        return FHE.sub(lhs, rhs);
    }

    /// @notice Performs the eq operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the eq
    function eq(euint16 lhs, euint16 rhs) internal returns (ebool) {
        return FHE.eq(lhs, rhs);
    }

    /// @notice Performs the ne operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the ne
    function ne(euint16 lhs, euint16 rhs) internal returns (ebool) {
        return FHE.ne(lhs, rhs);
    }

    /// @notice Performs the not operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @return the result of the not
    function not(euint16 lhs) internal returns (euint16) {
        return FHE.not(lhs);
    }

    /// @notice Performs the and operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the and
    function and(euint16 lhs, euint16 rhs) internal returns (euint16) {
        return FHE.and(lhs, rhs);
    }

    /// @notice Performs the or operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the or
    function or(euint16 lhs, euint16 rhs) internal returns (euint16) {
        return FHE.or(lhs, rhs);
    }

    /// @notice Performs the xor operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the xor
    function xor(euint16 lhs, euint16 rhs) internal returns (euint16) {
        return FHE.xor(lhs, rhs);
    }

    /// @notice Performs the gt operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the gt
    function gt(euint16 lhs, euint16 rhs) internal returns (ebool) {
        return FHE.gt(lhs, rhs);
    }

    /// @notice Performs the gte operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the gte
    function gte(euint16 lhs, euint16 rhs) internal returns (ebool) {
        return FHE.gte(lhs, rhs);
    }

    /// @notice Performs the lt operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the lt
    function lt(euint16 lhs, euint16 rhs) internal returns (ebool) {
        return FHE.lt(lhs, rhs);
    }

    /// @notice Performs the lte operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the lte
    function lte(euint16 lhs, euint16 rhs) internal returns (ebool) {
        return FHE.lte(lhs, rhs);
    }

    /// @notice Performs the rem operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the rem
    function rem(euint16 lhs, euint16 rhs) internal returns (euint16) {
        return FHE.rem(lhs, rhs);
    }

    /// @notice Performs the max operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the max
    function max(euint16 lhs, euint16 rhs) internal returns (euint16) {
        return FHE.max(lhs, rhs);
    }

    /// @notice Performs the min operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the min
    function min(euint16 lhs, euint16 rhs) internal returns (euint16) {
        return FHE.min(lhs, rhs);
    }

    /// @notice Performs the shl operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the shl
    function shl(euint16 lhs, euint16 rhs) internal returns (euint16) {
        return FHE.shl(lhs, rhs);
    }

    /// @notice Performs the shr operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the shr
    function shr(euint16 lhs, euint16 rhs) internal returns (euint16) {
        return FHE.shr(lhs, rhs);
    }

    /// @notice Performs the rol operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the rol
    function rol(euint16 lhs, euint16 rhs) internal returns (euint16) {
        return FHE.rol(lhs, rhs);
    }

    /// @notice Performs the ror operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @param rhs second input of type euint16
    /// @return the result of the ror
    function ror(euint16 lhs, euint16 rhs) internal returns (euint16) {
        return FHE.ror(lhs, rhs);
    }

    /// @notice Performs the square operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint16
    /// @return the result of the square
    function square(euint16 lhs) internal returns (euint16) {
        return FHE.square(lhs);
    }
    function toBool(euint16 value) internal  returns (ebool) {
        return FHE.asEbool(value);
    }
    function toU8(euint16 value) internal returns (euint8) {
        return FHE.asEuint8(value);
    }
    function toU32(euint16 value) internal returns (euint32) {
        return FHE.asEuint32(value);
    }
    function toU64(euint16 value) internal returns (euint64) {
        return FHE.asEuint64(value);
    }
    function toU128(euint16 value) internal returns (euint128) {
        return FHE.asEuint128(value);
    }
    function allow(euint16 ctHash, address account) internal {
        FHE.allow(ctHash, account);
    }
    function isAllowed(euint16 ctHash, address account) internal view returns (bool) {
        return FHE.isAllowed(ctHash, account);
    }
    function isPubliclyAllowed(euint16 ctHash) internal view returns (bool) {
        return FHE.isPubliclyAllowed(ctHash);
    }
    function allowThis(euint16 ctHash) internal {
        FHE.allowThis(ctHash);
    }
    function allowGlobal(euint16 ctHash) internal {
        FHE.allowGlobal(ctHash);
    }
    function allowPublic(euint16 ctHash) internal {
        FHE.allowPublic(ctHash);
    }
    function allowSender(euint16 ctHash) internal {
        FHE.allowSender(ctHash);
    }
    function allowTransient(euint16 ctHash, address account) internal {
        FHE.allowTransient(ctHash, account);
    }
    /// @notice Returns true if the encrypted uint16 is initialized and false otherwise
    /// @param value the encrypted uint16 value to check
    /// @return true if initialized, false otherwise
    function isInitialized(euint16 value) internal pure returns (bool) {
        return FHE.isInitialized(value);
    }
    /// @notice Unwraps an encrypted uint16 value to its underlying bytes32 handle
    /// @param value the encrypted uint16 value to unwrap
    /// @return the underlying bytes32 handle
    function unwrap(euint16 value) internal pure returns (bytes32) {
        return FHE.unwrap(value);
    }
}

using BindingsEuint32 for euint32 global;
library BindingsEuint32 {

    /// @notice Performs the add operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the add
    function add(euint32 lhs, euint32 rhs) internal returns (euint32) {
        return FHE.add(lhs, rhs);
    }

    /// @notice Performs the mul operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the mul
    function mul(euint32 lhs, euint32 rhs) internal returns (euint32) {
        return FHE.mul(lhs, rhs);
    }

    /// @notice Performs the div operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the div
    function div(euint32 lhs, euint32 rhs) internal returns (euint32) {
        return FHE.div(lhs, rhs);
    }

    /// @notice Performs the sub operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the sub
    function sub(euint32 lhs, euint32 rhs) internal returns (euint32) {
        return FHE.sub(lhs, rhs);
    }

    /// @notice Performs the eq operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the eq
    function eq(euint32 lhs, euint32 rhs) internal returns (ebool) {
        return FHE.eq(lhs, rhs);
    }

    /// @notice Performs the ne operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the ne
    function ne(euint32 lhs, euint32 rhs) internal returns (ebool) {
        return FHE.ne(lhs, rhs);
    }

    /// @notice Performs the not operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @return the result of the not
    function not(euint32 lhs) internal returns (euint32) {
        return FHE.not(lhs);
    }

    /// @notice Performs the and operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the and
    function and(euint32 lhs, euint32 rhs) internal returns (euint32) {
        return FHE.and(lhs, rhs);
    }

    /// @notice Performs the or operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the or
    function or(euint32 lhs, euint32 rhs) internal returns (euint32) {
        return FHE.or(lhs, rhs);
    }

    /// @notice Performs the xor operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the xor
    function xor(euint32 lhs, euint32 rhs) internal returns (euint32) {
        return FHE.xor(lhs, rhs);
    }

    /// @notice Performs the gt operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the gt
    function gt(euint32 lhs, euint32 rhs) internal returns (ebool) {
        return FHE.gt(lhs, rhs);
    }

    /// @notice Performs the gte operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the gte
    function gte(euint32 lhs, euint32 rhs) internal returns (ebool) {
        return FHE.gte(lhs, rhs);
    }

    /// @notice Performs the lt operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the lt
    function lt(euint32 lhs, euint32 rhs) internal returns (ebool) {
        return FHE.lt(lhs, rhs);
    }

    /// @notice Performs the lte operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the lte
    function lte(euint32 lhs, euint32 rhs) internal returns (ebool) {
        return FHE.lte(lhs, rhs);
    }

    /// @notice Performs the rem operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the rem
    function rem(euint32 lhs, euint32 rhs) internal returns (euint32) {
        return FHE.rem(lhs, rhs);
    }

    /// @notice Performs the max operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the max
    function max(euint32 lhs, euint32 rhs) internal returns (euint32) {
        return FHE.max(lhs, rhs);
    }

    /// @notice Performs the min operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the min
    function min(euint32 lhs, euint32 rhs) internal returns (euint32) {
        return FHE.min(lhs, rhs);
    }

    /// @notice Performs the shl operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the shl
    function shl(euint32 lhs, euint32 rhs) internal returns (euint32) {
        return FHE.shl(lhs, rhs);
    }

    /// @notice Performs the shr operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the shr
    function shr(euint32 lhs, euint32 rhs) internal returns (euint32) {
        return FHE.shr(lhs, rhs);
    }

    /// @notice Performs the rol operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the rol
    function rol(euint32 lhs, euint32 rhs) internal returns (euint32) {
        return FHE.rol(lhs, rhs);
    }

    /// @notice Performs the ror operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @param rhs second input of type euint32
    /// @return the result of the ror
    function ror(euint32 lhs, euint32 rhs) internal returns (euint32) {
        return FHE.ror(lhs, rhs);
    }

    /// @notice Performs the square operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint32
    /// @return the result of the square
    function square(euint32 lhs) internal returns (euint32) {
        return FHE.square(lhs);
    }
    function toBool(euint32 value) internal  returns (ebool) {
        return FHE.asEbool(value);
    }
    function toU8(euint32 value) internal returns (euint8) {
        return FHE.asEuint8(value);
    }
    function toU16(euint32 value) internal returns (euint16) {
        return FHE.asEuint16(value);
    }
    function toU64(euint32 value) internal returns (euint64) {
        return FHE.asEuint64(value);
    }
    function toU128(euint32 value) internal returns (euint128) {
        return FHE.asEuint128(value);
    }
    function allow(euint32 ctHash, address account) internal {
        FHE.allow(ctHash, account);
    }
    function isAllowed(euint32 ctHash, address account) internal view returns (bool) {
        return FHE.isAllowed(ctHash, account);
    }
    function isPubliclyAllowed(euint32 ctHash) internal view returns (bool) {
        return FHE.isPubliclyAllowed(ctHash);
    }
    function allowThis(euint32 ctHash) internal {
        FHE.allowThis(ctHash);
    }
    function allowGlobal(euint32 ctHash) internal {
        FHE.allowGlobal(ctHash);
    }
    function allowPublic(euint32 ctHash) internal {
        FHE.allowPublic(ctHash);
    }
    function allowSender(euint32 ctHash) internal {
        FHE.allowSender(ctHash);
    }
    function allowTransient(euint32 ctHash, address account) internal {
        FHE.allowTransient(ctHash, account);
    }
    /// @notice Returns true if the encrypted uint32 is initialized and false otherwise
    /// @param value the encrypted uint32 value to check
    /// @return true if initialized, false otherwise
    function isInitialized(euint32 value) internal pure returns (bool) {
        return FHE.isInitialized(value);
    }
    /// @notice Unwraps an encrypted uint32 value to its underlying bytes32 handle
    /// @param value the encrypted uint32 value to unwrap
    /// @return the underlying bytes32 handle
    function unwrap(euint32 value) internal pure returns (bytes32) {
        return FHE.unwrap(value);
    }
}

using BindingsEuint64 for euint64 global;
library BindingsEuint64 {

    /// @notice Performs the add operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the add
    function add(euint64 lhs, euint64 rhs) internal returns (euint64) {
        return FHE.add(lhs, rhs);
    }

    /// @notice Performs the mul operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the mul
    function mul(euint64 lhs, euint64 rhs) internal returns (euint64) {
        return FHE.mul(lhs, rhs);
    }

    /// @notice Performs the div operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the div
    function div(euint64 lhs, euint64 rhs) internal returns (euint64) {
        return FHE.div(lhs, rhs);
    }

    /// @notice Performs the sub operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the sub
    function sub(euint64 lhs, euint64 rhs) internal returns (euint64) {
        return FHE.sub(lhs, rhs);
    }

    /// @notice Performs the eq operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the eq
    function eq(euint64 lhs, euint64 rhs) internal returns (ebool) {
        return FHE.eq(lhs, rhs);
    }

    /// @notice Performs the ne operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the ne
    function ne(euint64 lhs, euint64 rhs) internal returns (ebool) {
        return FHE.ne(lhs, rhs);
    }

    /// @notice Performs the not operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @return the result of the not
    function not(euint64 lhs) internal returns (euint64) {
        return FHE.not(lhs);
    }

    /// @notice Performs the and operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the and
    function and(euint64 lhs, euint64 rhs) internal returns (euint64) {
        return FHE.and(lhs, rhs);
    }

    /// @notice Performs the or operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the or
    function or(euint64 lhs, euint64 rhs) internal returns (euint64) {
        return FHE.or(lhs, rhs);
    }

    /// @notice Performs the xor operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the xor
    function xor(euint64 lhs, euint64 rhs) internal returns (euint64) {
        return FHE.xor(lhs, rhs);
    }

    /// @notice Performs the gt operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the gt
    function gt(euint64 lhs, euint64 rhs) internal returns (ebool) {
        return FHE.gt(lhs, rhs);
    }

    /// @notice Performs the gte operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the gte
    function gte(euint64 lhs, euint64 rhs) internal returns (ebool) {
        return FHE.gte(lhs, rhs);
    }

    /// @notice Performs the lt operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the lt
    function lt(euint64 lhs, euint64 rhs) internal returns (ebool) {
        return FHE.lt(lhs, rhs);
    }

    /// @notice Performs the lte operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the lte
    function lte(euint64 lhs, euint64 rhs) internal returns (ebool) {
        return FHE.lte(lhs, rhs);
    }

    /// @notice Performs the rem operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the rem
    function rem(euint64 lhs, euint64 rhs) internal returns (euint64) {
        return FHE.rem(lhs, rhs);
    }

    /// @notice Performs the max operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the max
    function max(euint64 lhs, euint64 rhs) internal returns (euint64) {
        return FHE.max(lhs, rhs);
    }

    /// @notice Performs the min operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the min
    function min(euint64 lhs, euint64 rhs) internal returns (euint64) {
        return FHE.min(lhs, rhs);
    }

    /// @notice Performs the shl operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the shl
    function shl(euint64 lhs, euint64 rhs) internal returns (euint64) {
        return FHE.shl(lhs, rhs);
    }

    /// @notice Performs the shr operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the shr
    function shr(euint64 lhs, euint64 rhs) internal returns (euint64) {
        return FHE.shr(lhs, rhs);
    }

    /// @notice Performs the rol operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the rol
    function rol(euint64 lhs, euint64 rhs) internal returns (euint64) {
        return FHE.rol(lhs, rhs);
    }

    /// @notice Performs the ror operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @param rhs second input of type euint64
    /// @return the result of the ror
    function ror(euint64 lhs, euint64 rhs) internal returns (euint64) {
        return FHE.ror(lhs, rhs);
    }

    /// @notice Performs the square operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint64
    /// @return the result of the square
    function square(euint64 lhs) internal returns (euint64) {
        return FHE.square(lhs);
    }
    function toBool(euint64 value) internal  returns (ebool) {
        return FHE.asEbool(value);
    }
    function toU8(euint64 value) internal returns (euint8) {
        return FHE.asEuint8(value);
    }
    function toU16(euint64 value) internal returns (euint16) {
        return FHE.asEuint16(value);
    }
    function toU32(euint64 value) internal returns (euint32) {
        return FHE.asEuint32(value);
    }
    function toU128(euint64 value) internal returns (euint128) {
        return FHE.asEuint128(value);
    }
    function allow(euint64 ctHash, address account) internal {
        FHE.allow(ctHash, account);
    }
    function isAllowed(euint64 ctHash, address account) internal view returns (bool) {
        return FHE.isAllowed(ctHash, account);
    }
    function isPubliclyAllowed(euint64 ctHash) internal view returns (bool) {
        return FHE.isPubliclyAllowed(ctHash);
    }
    function allowThis(euint64 ctHash) internal {
        FHE.allowThis(ctHash);
    }
    function allowGlobal(euint64 ctHash) internal {
        FHE.allowGlobal(ctHash);
    }
    function allowPublic(euint64 ctHash) internal {
        FHE.allowPublic(ctHash);
    }
    function allowSender(euint64 ctHash) internal {
        FHE.allowSender(ctHash);
    }
    function allowTransient(euint64 ctHash, address account) internal {
        FHE.allowTransient(ctHash, account);
    }
    /// @notice Returns true if the encrypted uint64 is initialized and false otherwise
    /// @param value the encrypted uint64 value to check
    /// @return true if initialized, false otherwise
    function isInitialized(euint64 value) internal pure returns (bool) {
        return FHE.isInitialized(value);
    }
    /// @notice Unwraps an encrypted uint64 value to its underlying bytes32 handle
    /// @param value the encrypted uint64 value to unwrap
    /// @return the underlying bytes32 handle
    function unwrap(euint64 value) internal pure returns (bytes32) {
        return FHE.unwrap(value);
    }
}

using BindingsEuint128 for euint128 global;
library BindingsEuint128 {

    /// @notice Performs the add operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the add
    function add(euint128 lhs, euint128 rhs) internal returns (euint128) {
        return FHE.add(lhs, rhs);
    }

    /// @notice Performs the mul operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the mul
    function mul(euint128 lhs, euint128 rhs) internal returns (euint128) {
        return FHE.mul(lhs, rhs);
    }

    /// @notice Performs the div operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the div
    function div(euint128 lhs, euint128 rhs) internal returns (euint128) {
        return FHE.div(lhs, rhs);
    }

    /// @notice Performs the sub operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the sub
    function sub(euint128 lhs, euint128 rhs) internal returns (euint128) {
        return FHE.sub(lhs, rhs);
    }

    /// @notice Performs the eq operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the eq
    function eq(euint128 lhs, euint128 rhs) internal returns (ebool) {
        return FHE.eq(lhs, rhs);
    }

    /// @notice Performs the ne operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the ne
    function ne(euint128 lhs, euint128 rhs) internal returns (ebool) {
        return FHE.ne(lhs, rhs);
    }

    /// @notice Performs the not operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @return the result of the not
    function not(euint128 lhs) internal returns (euint128) {
        return FHE.not(lhs);
    }

    /// @notice Performs the and operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the and
    function and(euint128 lhs, euint128 rhs) internal returns (euint128) {
        return FHE.and(lhs, rhs);
    }

    /// @notice Performs the or operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the or
    function or(euint128 lhs, euint128 rhs) internal returns (euint128) {
        return FHE.or(lhs, rhs);
    }

    /// @notice Performs the xor operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the xor
    function xor(euint128 lhs, euint128 rhs) internal returns (euint128) {
        return FHE.xor(lhs, rhs);
    }

    /// @notice Performs the gt operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the gt
    function gt(euint128 lhs, euint128 rhs) internal returns (ebool) {
        return FHE.gt(lhs, rhs);
    }

    /// @notice Performs the gte operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the gte
    function gte(euint128 lhs, euint128 rhs) internal returns (ebool) {
        return FHE.gte(lhs, rhs);
    }

    /// @notice Performs the lt operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the lt
    function lt(euint128 lhs, euint128 rhs) internal returns (ebool) {
        return FHE.lt(lhs, rhs);
    }

    /// @notice Performs the lte operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the lte
    function lte(euint128 lhs, euint128 rhs) internal returns (ebool) {
        return FHE.lte(lhs, rhs);
    }

    /// @notice Performs the rem operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the rem
    function rem(euint128 lhs, euint128 rhs) internal returns (euint128) {
        return FHE.rem(lhs, rhs);
    }

    /// @notice Performs the max operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the max
    function max(euint128 lhs, euint128 rhs) internal returns (euint128) {
        return FHE.max(lhs, rhs);
    }

    /// @notice Performs the min operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the min
    function min(euint128 lhs, euint128 rhs) internal returns (euint128) {
        return FHE.min(lhs, rhs);
    }

    /// @notice Performs the shl operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the shl
    function shl(euint128 lhs, euint128 rhs) internal returns (euint128) {
        return FHE.shl(lhs, rhs);
    }

    /// @notice Performs the shr operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the shr
    function shr(euint128 lhs, euint128 rhs) internal returns (euint128) {
        return FHE.shr(lhs, rhs);
    }

    /// @notice Performs the rol operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the rol
    function rol(euint128 lhs, euint128 rhs) internal returns (euint128) {
        return FHE.rol(lhs, rhs);
    }

    /// @notice Performs the ror operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @param rhs second input of type euint128
    /// @return the result of the ror
    function ror(euint128 lhs, euint128 rhs) internal returns (euint128) {
        return FHE.ror(lhs, rhs);
    }

    /// @notice Performs the square operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type euint128
    /// @return the result of the square
    function square(euint128 lhs) internal returns (euint128) {
        return FHE.square(lhs);
    }
    function toBool(euint128 value) internal  returns (ebool) {
        return FHE.asEbool(value);
    }
    function toU8(euint128 value) internal returns (euint8) {
        return FHE.asEuint8(value);
    }
    function toU16(euint128 value) internal returns (euint16) {
        return FHE.asEuint16(value);
    }
    function toU32(euint128 value) internal returns (euint32) {
        return FHE.asEuint32(value);
    }
    function toU64(euint128 value) internal returns (euint64) {
        return FHE.asEuint64(value);
    }
    function allow(euint128 ctHash, address account) internal {
        FHE.allow(ctHash, account);
    }
    function isAllowed(euint128 ctHash, address account) internal view returns (bool) {
        return FHE.isAllowed(ctHash, account);
    }
    function isPubliclyAllowed(euint128 ctHash) internal view returns (bool) {
        return FHE.isPubliclyAllowed(ctHash);
    }
    function allowThis(euint128 ctHash) internal {
        FHE.allowThis(ctHash);
    }
    function allowGlobal(euint128 ctHash) internal {
        FHE.allowGlobal(ctHash);
    }
    function allowPublic(euint128 ctHash) internal {
        FHE.allowPublic(ctHash);
    }
    function allowSender(euint128 ctHash) internal {
        FHE.allowSender(ctHash);
    }
    function allowTransient(euint128 ctHash, address account) internal {
        FHE.allowTransient(ctHash, account);
    }
    /// @notice Returns true if the encrypted uint128 is initialized and false otherwise
    /// @param value the encrypted uint128 value to check
    /// @return true if initialized, false otherwise
    function isInitialized(euint128 value) internal pure returns (bool) {
        return FHE.isInitialized(value);
    }
    /// @notice Unwraps an encrypted uint128 value to its underlying bytes32 handle
    /// @param value the encrypted uint128 value to unwrap
    /// @return the underlying bytes32 handle
    function unwrap(euint128 value) internal pure returns (bytes32) {
        return FHE.unwrap(value);
    }
}

using BindingsEaddress for eaddress global;
library BindingsEaddress {

    /// @notice Performs the eq operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type eaddress
    /// @param rhs second input of type eaddress
    /// @return the result of the eq
    function eq(eaddress lhs, eaddress rhs) internal returns (ebool) {
        return FHE.eq(lhs, rhs);
    }

    /// @notice Performs the ne operation
    /// @dev Pure in this function is marked as a hack/workaround - note that this function is NOT pure as fetches of ciphertexts require state access
    /// @param lhs input of type eaddress
    /// @param rhs second input of type eaddress
    /// @return the result of the ne
    function ne(eaddress lhs, eaddress rhs) internal returns (ebool) {
        return FHE.ne(lhs, rhs);
    }
    function toBool(eaddress value) internal  returns (ebool) {
        return FHE.asEbool(value);
    }
    function toU8(eaddress value) internal returns (euint8) {
        return FHE.asEuint8(value);
    }
    function toU16(eaddress value) internal returns (euint16) {
        return FHE.asEuint16(value);
    }
    function toU32(eaddress value) internal returns (euint32) {
        return FHE.asEuint32(value);
    }
    function toU64(eaddress value) internal returns (euint64) {
        return FHE.asEuint64(value);
    }
    function toU128(eaddress value) internal returns (euint128) {
        return FHE.asEuint128(value);
    }
    function allow(eaddress ctHash, address account) internal {
        FHE.allow(ctHash, account);
    }
    function isAllowed(eaddress ctHash, address account) internal view returns (bool) {
        return FHE.isAllowed(ctHash, account);
    }
    function isPubliclyAllowed(eaddress ctHash) internal view returns (bool) {
        return FHE.isPubliclyAllowed(ctHash);
    }
    function allowThis(eaddress ctHash) internal {
        FHE.allowThis(ctHash);
    }
    function allowGlobal(eaddress ctHash) internal {
        FHE.allowGlobal(ctHash);
    }
    function allowPublic(eaddress ctHash) internal {
        FHE.allowPublic(ctHash);
    }
    function allowSender(eaddress ctHash) internal {
        FHE.allowSender(ctHash);
    }
    function allowTransient(eaddress ctHash, address account) internal {
        FHE.allowTransient(ctHash, account);
    }
    /// @notice Returns true if the encrypted address is initialized and false otherwise
    /// @param value the encrypted address value to check
    /// @return true if initialized, false otherwise
    function isInitialized(eaddress value) internal pure returns (bool) {
        return FHE.isInitialized(value);
    }
    /// @notice Unwraps an encrypted address value to its underlying bytes32 handle
    /// @param value the encrypted address value to unwrap
    /// @return the underlying bytes32 handle
    function unwrap(eaddress value) internal pure returns (bytes32) {
        return FHE.unwrap(value);
    }
}
