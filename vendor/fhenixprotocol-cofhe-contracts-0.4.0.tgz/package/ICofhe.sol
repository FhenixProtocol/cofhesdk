// SPDX-License-Identifier: UNLICENSED
pragma solidity >=0.8.25 <0.9.0;

struct EncryptedInput {
    uint256 ctHash;
    uint8 securityZone;
    uint8 utype;
    bytes signature;
}

struct UnsignedEncryptedInput {
    uint256 ctHash;
    uint8 securityZone;
    uint8 utype;
}

// Order is set as in fheos/precompiles/types/types.go
enum FunctionId {
    _0,             // 0 - GetNetworkKey
    _1,             // 1 - Verify
    cast,           // 2
    sealoutput,     // 3
    select,         // 4 - select
    _5,             // 5 - req
    decrypt,        // 6
    sub,            // 7
    add,            // 8
    xor,            // 9
    and,            // 10
    or,             // 11
    not,            // 12
    div,            // 13
    rem,            // 14
    mul,            // 15
    shl,            // 16
    shr,            // 17
    gte,            // 18
    lte,            // 19
    lt,             // 20
    gt,             // 21
    min,            // 22
    max,            // 23
    eq,             // 24
    ne,             // 25
    trivialEncrypt, // 26
    random,         // 27
    rol,            // 28
    ror,            // 29
    square,         // 30
    _31             // 31
}

interface ICoFHEAddressBook {
    function getTm(uint256 id) external view returns (address);
}

interface ITaskManager {
    function createTask(uint8 returnType, FunctionId funcId, uint256[] memory encryptedInputs, uint256[] memory extraInputs) external returns (uint256);
    function createRandomTask(uint8 returnType, uint256 seed, int32 securityZone) external returns (uint256);

    function batchVerifyInputs(UnsignedEncryptedInput[] memory inputs, address sender, bytes memory signature) external returns (uint256[] memory);

    function allow(uint256 ctHash, address account) external;
    function isAllowed(uint256 ctHash, address account) external view returns (bool);
    function isPubliclyAllowed(uint256 ctHash) external view returns (bool);
    function allowGlobal(uint256 ctHash) external;
    function allowTransient(uint256 ctHash, address account) external;
    function shareCtHash(uint256 ctHash, address receiver) external;
    function receiveCtHash(uint256 ctHash, address expectedSharer) external;
    function getDecryptResultSafe(uint256 ctHash) external view returns (uint256, bool);
    function getDecryptResult(uint256 ctHash) external view returns (uint256);

    function publishDecryptResult(uint256 ctHash, uint256 result, bytes calldata signature) external;
    function publishDecryptResultBatch(uint256[] calldata ctHashes, uint256[] calldata results, bytes[] calldata signatures) external;
    function verifyDecryptResult(uint256 ctHash, uint256 result, bytes calldata signature) external view returns (bool);
    function verifyDecryptResultSafe(
        uint256 ctHash,
        uint256 result,
        bytes calldata signature
    ) external view returns (bool);
    function verifyDecryptResultBatch(uint256[] calldata ctHashes, uint256[] calldata results, bytes[] calldata signatures) external view returns (bool);
    function verifyDecryptResultBatchSafe(uint256[] calldata ctHashes, uint256[] calldata results, bytes[] calldata signatures) external view returns (bool[] memory);
}

library Utils {
    error InvalidEncryptedInput(uint8 got, uint8 expected);

    // Values used to communicate types to the runtime.
    // Must match values defined in warp-drive protobufs for everything to
    uint8 internal constant EUINT8_TFHE = 2;
    uint8 internal constant EUINT16_TFHE = 3;
    uint8 internal constant EUINT32_TFHE = 4;
    uint8 internal constant EUINT64_TFHE = 5;
    uint8 internal constant EUINT128_TFHE = 6;
    uint8 internal constant EUINT256_TFHE = 8;
    uint8 internal constant EADDRESS_TFHE = 7;
    uint8 internal constant EBOOL_TFHE = 0;

    function functionIdToString(FunctionId _functionId) internal pure returns (string memory) {
        if (_functionId == FunctionId.cast) return "cast";
        if (_functionId == FunctionId.sealoutput) return "sealOutput";
        if (_functionId == FunctionId.select) return "select";
        if (_functionId == FunctionId.decrypt) return "decrypt";
        if (_functionId == FunctionId.sub) return "sub";
        if (_functionId == FunctionId.add) return "add";
        if (_functionId == FunctionId.xor) return "xor";
        if (_functionId == FunctionId.and) return "and";
        if (_functionId == FunctionId.or) return "or";
        if (_functionId == FunctionId.not) return "not";
        if (_functionId == FunctionId.div) return "div";
        if (_functionId == FunctionId.rem) return "rem";
        if (_functionId == FunctionId.mul) return "mul";
        if (_functionId == FunctionId.shl) return "shl";
        if (_functionId == FunctionId.shr) return "shr";
        if (_functionId == FunctionId.gte) return "gte";
        if (_functionId == FunctionId.lte) return "lte";
        if (_functionId == FunctionId.lt) return "lt";
        if (_functionId == FunctionId.gt) return "gt";
        if (_functionId == FunctionId.min) return "min";
        if (_functionId == FunctionId.max) return "max";
        if (_functionId == FunctionId.eq) return "eq";
        if (_functionId == FunctionId.ne) return "ne";
        if (_functionId == FunctionId.trivialEncrypt) return "trivialEncrypt";
        if (_functionId == FunctionId.random) return "random";
        if (_functionId == FunctionId.rol) return "rol";
        if (_functionId == FunctionId.ror) return "ror";
        if (_functionId == FunctionId.square) return "square";

        return "";
    }

    function inputFromBytes(bytes memory data, uint8 expected) internal pure returns (EncryptedInput memory) {
        EncryptedInput memory v;
        (
            v.ctHash,
            v.securityZone,
            v.utype,
            v.signature
        ) = abi.decode(
            data,
            (uint256, uint8, uint8, bytes)
        );

        expectUtype(v.utype, expected);
        return v;
    }

    function batchInputEntryFromBytes(bytes memory data, uint8 expected) internal pure returns (UnsignedEncryptedInput memory) {
        UnsignedEncryptedInput memory v;
        (
            v.ctHash,
            v.securityZone,
            v.utype
        ) = abi.decode(data, (uint256, uint8, uint8));

        expectUtype(v.utype, expected);
        return v;
    }

    function batchInputsFromBytes(bytes[] memory data, uint8 expected) internal pure returns (UnsignedEncryptedInput[] memory) {
        UnsignedEncryptedInput[] memory inputs = new UnsignedEncryptedInput[](data.length);
        for (uint256 i = 0; i < data.length; i++) {
            inputs[i] = batchInputEntryFromBytes(data[i], expected);
        }
        return inputs;
    }

    function inputFromHashAndProof(
        bytes32 hash,
        bytes memory signature,
        uint8 utype,
        uint8 securityZone
    ) internal pure returns (EncryptedInput memory) {
        return EncryptedInput({
            ctHash: uint256(hash),
            securityZone: securityZone,
            utype: utype,
            signature: signature
        });
    }

    /// @dev Convenience overload that defaults to securityZone 0.
    function inputFromHashAndProof(bytes32 hash, bytes memory signature, uint8 utype) internal pure returns (EncryptedInput memory) {
        return inputFromHashAndProof(hash, signature, utype, 0);
    }

    function expectUtype(uint8 actual, uint8 expected) internal pure {
        if (actual != expected) {
            revert InvalidEncryptedInput(actual, expected);
        }
    }
}
